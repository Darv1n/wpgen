<?php

/**
 * Адаптация класса SafeMySQL под wpdb.
 *
 * Ссылки: https://github.com/colshrapnel/safemysql, http://phpfaq.ru/safemysql
 *
 * Методы аналоги WPDB:
 * insert( $table, $data )                  - вставляет данные в таблицу
 * replace( $table, $data )                 - заменяет данные в таблице, по уникальному ключу
 * delete( $table, $where )                 - удаляет данные из таблицы
 * update( $table, $data, $where )          - обновление записи (строки) в таблице
 * query($query,$param1,$param2, ...)       - returns mysqli resource.
 * get_var($query,$param1,$param2, ...)     - returns scalar value
 * get_row($query,$param1,$param2, ...)     - returns 1-dimensional array, a row
 * get_col($query,$param1,$param2, ...)     - returns 1-dimensional array, a column
 * get_results($query,$param1,$param2, ...) - returns 2-dimensional array, an array of rows
 * prepare($query,$param1,$param2, ...)     - очистка запроса (для совместимости с запросами WP).
 *                                            Ограничение: в prepare() нужно оборачивать весь запрос, а не его часть.
 *
 * Встроенные методы:
 * getAll($query,$param1,$param2, ...)      - returns 2-dimensional array, an array of rows
 * getInd($key,$query,$par1,$par2, ...)     - returns an indexed 2-dimensional array, an array of rows
 * getIndCol($key,$query,$par1,$par2, ...)  - returns 1-dimensional array, an indexed column, consists of key => value pairs
 *
 * Placeholders:
 * ?s/%s ("string") - strings (also DATE, FLOAT and DECIMAL)
 * ?i/%d ("integer") - the name says it all
 * ?n ("name") - identifiers (table and field names)
 * ?a ("array") - complex placeholder for IN() operator (substituted with string of 'a','b','c' format, without parentesis)
 * ?u ("update") - complex placeholder for SET operator (substituted with string of field='value',field='value' format)
 * ?p ("parsed") - special type placeholder, for inserting already parsed statements without any processing, to avoid double parsing.
 *
 * To get data right out of the query there are helper methods for the most used :
 * query($query,$param1,$param2, ...) - returns mysqli resource.
 * getOne($query,$param1,$param2, ...) - returns scalar value
 * getRow($query,$param1,$param2, ...) - returns 1-dimensional array, a row
 * getCol($query,$param1,$param2, ...) - returns 1-dimensional array, a column
 * getAll($query,$param1,$param2, ...) - returns 2-dimensional array, an array of rows
 * getInd($key,$query,$par1,$par2, ...) - returns an indexed 2-dimensional array, an array of rows
 * getIndCol($key,$query,$par1,$par2, ...) - returns 1-dimensional array, an indexed column, consists of key => value pairs
 *
 * For the whatever complex case always use parse() method. And insert already parsed parts via ?p placeholder
 *
 * LIKE example:
 * $sql   = "SELECT * FROM table WHERE ?n LIKE ?s";
 * $data  = $db->query( $sql, $field, "%$value%" );
 *
 * // проверки работы скрипта
 * //var_dump( $db->delete( $db->sites, array('script_url'=>'','hack_key'=>'---') ) );
 * //die();
 *
 * //var_dump( $db->update( $db->sites, array('note'=>'првоерка $db->update'), array('domain'=>'tue21.deile.com') ) );
 * //die;
 *
 * //print_r( $db->get_results("SELECT * FROM $db->sites LIMIT 5") );
 * //die;
 *
 * //print_r( $db->get_row("SELECT * FROM $db->sites LIMIT 5") );
 * //die;
 *
 * //print_r( $db->get_col("SELECT * FROM $db->sites LIMIT 5") );
 * //die;
 *
 * //print_r( $db->get_var("SELECT * FROM $db->sites ORDER BY id DESC LIMIT 5") );
 * //die;
 *
 * //print_r( $db->getIndCol('id', "SELECT * FROM $db->sites ORDER BY id DESC LIMIT 5") );
 * //die;
 *
 * //print_r( $db->getInd('domain', "SELECT * FROM $db->sites ORDER BY id DESC LIMIT 5") );
 * //die;
 *
 * //define( 'OBJECT', 'OBJECT' );
 * //define( 'object', 'OBJECT' ); // Back compat.
 * //define( 'OBJECT_K', 'OBJECT_K' );
 * //define( 'ARRAY_A', 'ARRAY_A' );
 * //define( 'ARRAY_N', 'ARRAY_N' );
 *
 * ver: 1.5
 */
class SafeMySQL_WP extends SafeMySQL {

	function __construct( $opt = array() ){

		parent::__construct( $opt );
	}

	function __get( $name ){

		if( 'insert_id' === $name )
			return $this->insertId();
	}

	// wrapper methods like WP method is

	public function insert( $table, $data ){

		$this->query('INSERT INTO ?n SET ?u', $table, $this->_unset_invalid_fields( $data ) );

		return $this->affectedRows();
	}

	public function replace( $table, $data ){

		return $this->query('REPLACE INTO ?n SET ?u', $table, $this->_unset_invalid_fields( $data ) );
	}

	public function delete( $table, $where ){
		$where  = $this->_where_join( $where );

		return $this->query('DELETE FROM ?n WHERE ?p', $table, $where );
	}

	public function update( $table, $data, $where ){

		if( ! $where )
			return false;

		$fields = $this->_unset_invalid_fields( $data );
		$where  = $this->_where_join( $where );

		$this->query('UPDATE ?n SET ?u WHERE ?p', $table, $fields, $where );

		return $this->affectedRows();
	}

	/**
	 * @return int Number of rows. 0 - no rows affected. -1 - sql error.
	 */
	public function query(){

		$args = $this->wpholders( func_get_args() );
		call_user_func_array( [ $this, 'parent::query' ], $args );

		return $this->affectedRows();
	}

	/**
	 * @return string|FALSE either first column of the first row of resultset or FALSE if none found.
	 */
	public function get_var(){

		$args = $this->wpholders( func_get_args() );

		return call_user_func_array( [ $this, 'getOne' ], $args );
	}

	public function get_row(){

		$args = $this->wpholders( func_get_args() );
		$res = call_user_func_array( [ $this, 'getRow' ], $args );

		if( is_array( $res ) ){
			return (object) $res;
		}

		return $res;
	}

	public function get_col(){

		$args = $this->wpholders( func_get_args() );
		$res = call_user_func_array( [ $this, 'getCol' ], $args );
		if( is_array( $res ) ){
			return (object) $res;
		}

		return $res;
	}

	/**
	 * @return array Or empty array
	 */
	public function get_results(){

		$args = $this->wpholders( func_get_args() );

		$res = call_user_func_array( [ $this, 'getAll' ], $args );

		if( is_array( $res ) ){
			foreach( $res as & $val ){
				$val = (object) $val;
			}
		}

		return $res;
	}

	public function prepare(){

		$args = func_get_args();
		$args[0] = str_replace( [ '%s', '%d' ], [ '?s', '?i' ], $args[0] );
		$res = call_user_func_array( [ $this, 'parse' ], $args );

		return [ '?p', $res ];
	}

	//  helpers

	/**
	 * convert to WP placeholders
	 *
	 * @param string|array $sql
	 *
	 * @return array|mixed
	 */
	private function wpholders( $sql ){

		if( is_array( $sql[0] ) ){
			$sql = $sql[0]; // parsed after prepare()
		}
		elseif( is_array( $sql ) ){
			$sql[0] = str_replace( [ '%s', '%d' ], [ '?s', '?i' ], $sql[0] ); // used SafeMySQL prepare method
		}

		return $sql;
	}

	## unset array element if value is: null or array(). For: insert, replace, update methods
	private function _unset_invalid_fields( $data ){

		foreach( $data as $k => $val ){

			if( $val === null || $val === [] ){
				unset( $data[ $k ] );
			}
		}

		return $data;
	}

	## NOTE: return sql save string
	private function _where_join( $data ){

		$data = $this->parse( '?u', $data );
		$data = str_replace( "',`", "' AND `", $data );

		return $data;
	}

}



