<?php

// !!! NOT WP environment !!!

/**
 * Detects if it is USER_AGENT of Bot.
 *
 * Based on data of http://www.useragentstring.com/pages/useragentstring.php
 *
 * @param string $USER_AGENT
 *
 * @return bool
 *
 * @ver 3
 */
function is_bot( $USER_AGENT = '' ){

	if( ! $USER_AGENT ){
		$USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
	}

	$bots = [
		'bot|(?<!MSIE)crawler|spider|spyder',   // common sifter
		'Search|curl|(?<!Hot)Java|Python|(?<!Fire)PHP',
		'Yandex|slurp|yahoo|Teoma|Scooter|ia_archiver|Lycos|Rambler|Mail\.Ru|Aport|WebAlta|ezooms|(?<!E)nigma',
		'technorati|findexa|findlinks|gaisbo|zyborg|bloglines|blogsearch|pubsub|syndic8|userland|become\.com',
		'Accoona|Arachmo|B-O-T|Drtrs|Charlotte|larbin|PycURL|w3\.org|W3C_Validator|Pompos|LinkWalker|Pompos|htdig',
		'libwww-perl|Xenu Link Sleuth|AppEngine-Google|Feedfetcher-Google|amaya|Thunderbird|Wget|WebCopier|Web Downloader',
		'lwp-trivial|iTunes|webcollage|WebCapture',
	];

	foreach( $bots as $pattern ){

		if( preg_match( "~$pattern~i", $USER_AGENT ) ){
			return true;
		}
	}

	return false;
}

/**
 * Detect Mobile Browsers.
 *
 * @see http://detectmobilebrowsers.com/
 */
function is_mobile( $USER_AGENT = '' ){

	if( ! $USER_AGENT ){
		$USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
	}

	$mobiles_regxe = [
		// cant be simple: `iPad`, `iPod`, `iPhone` it uses as mobile phone engine
		'webOS|BlackBerry|IEMobile|iPad|iPod|iPhone',
		'^Nokia|^SonyEricsson|Mobile$',
		'(?<= )(?:NetFront/|Minimo/|Fennec/|Mobile Safari|Fennec/|Maemo Browser |uZardWeb/|uZard/|MIB/|Opera Mini/|Opera Mobi/|Iris/)',
	];

	foreach( $mobiles_regxe as $pattern ){

		if( preg_match( "~$pattern~i", $USER_AGENT ) ){
			return true;
		}
	}

	return false;
}

/**
 * Die with json error message.
 * If string is passed in $data it will be treats as error message.
 *
 * @param string|array $data
 */
function json_die( $data, $type = 'ok' ){

	$res = [ 'type' => $type ];

	if( is_string( $data ) ){
		$res += [ 'msg' => "Kama Postviews: $data" ];
	}
	else {
		$res += $data;
	}

	echo json_encode( $res );

	exit;
}

/**
 * SET DB connection.
 *
 * @return SafeMySQL_WP
 */
function get_db_connection(){

	try {

		$db = new SafeMySQL_WP( [
			'db'      => DB_NAME,
			'user'    => DB_USER,
			'pass'    => DB_PASSWORD,
			'host'    => trim( DB_HOST, ':' ), // localhost: >>> localhost
			'charset' => DB_CHARSET,
		] );
	}
	catch( Exception $e ){
		json_die( 'ERROR DB connection: '. ( KPV_DEBUG ? $e->getMessage() : 'Enable KPV_DEBUG to see the error' ), 'error' );
	}

	return $db;
}

/**
 * Parse wp-config.php file and return code for eval.
 *
 * @param object $options
 *
 * @return string
 */
function parse_wp_config( $wpconfig_droot_relpath ){

	// look for the 'wp-config.php'
	foreach( [
		@ realpath( $_SERVER['DOCUMENT_ROOT'] . "/$wpconfig_droot_relpath/wp-config.php" ),
		dirname( __DIR__, 2 ), // wp-content
		dirname( __DIR__, 3 ),
		dirname( __DIR__, 4 ),
		dirname( __DIR__, 5 ),
	] as $wp_config_path ){

		if( @ file_exists( $wp_config_path ) ){
			break;
		}
	}

	if( ! $wp_config_path ){
		json_die( 'ERROR: wp-config.php not found.', 'error' );
	}

	// strip PHP comments & whitespace. Comments may contain conflict code.
	$wp_config_content = php_strip_whitespace( $wp_config_path );

	if( ! $wp_config_content ){
		json_die( 'ERROR: wp-config.php content is empty...', 'error' );
	}


	// match table_prefix
	if( ! preg_match( '~\$table_prefix[^;]+;~', $wp_config_content, $mm ) ){
		json_die( 'ERROR: $table_prefix not found in wp-config.php.', 'error' );
	}

	$eval = [];

	// $table_prefix
	$eval[] = $mm[0];

	// match DB Connections. Note: constant val cen be an empty string
	$constants_patt = '(?<names>DB_NAME|DB_USER|DB_PASSWORD|DB_HOST|DB_CHARSET|DB_COLLATE|KPV_META_KEY|KPV_PREV_MONTH_META_KEY)'.
	                  '(?:[\'"]\s*,|\s*=)\s*([\'"])(?<vals>[^\'"]*)\2\s*\)?\s*;';

	if( ! preg_match_all( "/$constants_patt/", $wp_config_content, $mm ) ){
		die( 'ERROR: wp-config CONSTANTS not found.' );
	}

	foreach( $mm['names'] as $index => $name ){
		$val = $mm['vals'][ $index ];
		$eval[] = "define( '$name', '$val' );";
	}

	return implode( PHP_EOL, $eval );
}

function set_http_headers(){

	@ header( 'Content-Type: application/json; charset=utf-8' );

	/**
	 * Set the headers to prevent caching for the different browsers.
	 *
	 * Different browsers support different nocache headers, so several
	 * headers must be sent so that all of them get the point that no
	 * caching should occur.
	 *
	 * @see https://wp-kama.com/function/nocache_headers
	 */
	$headers = [
		'X-Robots-Tag' => 'noindex',
		'X-Accel-Expires' => '0',

		// @see https://wp-kama.com/function/wp_get_nocache_headers
		'Expires'       => 'Wed, 11 Jan 1984 05:00:00 GMT',
		'Cache-Control' => 'no-cache, must-revalidate, max-age=0, smax-age=0',
		'Pragma'        => 'no-cache',
	];

	header_remove( 'Last-Modified' );

	foreach( $headers as $name => $field_value ){
		@ header( "$name: $field_value" );
	}

	// ensure headers are send.
	flush();
}

