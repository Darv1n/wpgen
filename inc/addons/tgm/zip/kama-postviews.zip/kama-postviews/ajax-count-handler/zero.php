<?php

// no WP
defined( 'ABSPATH' ) && exit;

const KPV_DEBUG = 0;

require_once __DIR__ . '/../src/functions/common.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/SafeMySQL.php';
require_once __DIR__ . '/SafeMySQL_WP.php';
require_once __DIR__ . '/Log_Table_Engine.php';
require_once __DIR__ . '/Count_Visit.php';

if( KPV_DEBUG ){
	error_reporting( E_ALL );
	ini_set( 'display_errors', 1 );
}
else {
	error_reporting( 0 );
	ini_set( 'display_errors', 0 );
}

set_http_headers();

// block bots
if( is_bot() ){
	json_die( 'It is a Bot', 'info' );
}

// do not stop when user ended the connection.
@ ignore_user_abort( true );

$input = file_get_contents( 'php://input' );
$input = json_decode( $input, false );
$opt = json_decode( $input->options, false );

// sanitize input data
$data = (object) [
	'obj_id'    => (int) $input->obj_id, // !!! 0 is allowed,
	'obj_type'  => kpv_sanitize_db_obj_type( $input->obj_type ),
	'type_name' => kpv_sanitize_db_obj_type( $input->type_name ), // 'post_type' or 'taxonomy' name,
	'referrer'  => ( false === filter_var( $input->referrer, FILTER_VALIDATE_URL ) ) ? '' : $input->referrer,
	'user_id'   => (int) $input->user_id,
	'options'   => (object) [
		'show_prev_m_views'       => (bool) $opt->show_prev_m_views,
		'_wpconfig_droot_relpath' => preg_replace( '~[^\w/\\\\_. -]~', '', $opt->_wpconfig_droot_relpath ),
		'hold_sec_between_counts' => (int) $opt->hold_sec_between_counts,
		'allowed_meta_keys' => array_map( 'kpv_sanitize_db_obj_type', array_filter( array_map( 'trim', explode( ',', $opt->allowed_meta_keys ) ) ) ),
	],
];

if( ! $data->obj_type ){
	json_die( 'ERROR: no $data->obj_type', 'error' );
}

$eval = parse_wp_config( $data->options->_wpconfig_droot_relpath );
eval( $eval );

kpv_set_constants(); // after eval

$GLOBALS['db'] = get_db_connection();

/** @noinspection PhpUndefinedVariableInspection */
$db->prefix = $table_prefix;
$db->postviews          = $db->prefix . 'postviews';
$db->postviews_meta     = $db->prefix . 'postviews_meta';
$db->postviews_temp_log = $db->prefix . 'postviews_temp_log';

$count = new Count_Visit( $data );
$count->count_visit();

if( $count->skiped ){
	json_die( 'This visit is skiped', 'info' );
}

if( $count->views_count ){

	$diff = round( microtime( true ) - $_SERVER['REQUEST_TIME_FLOAT'], 5 );

	json_die( [
		'exec_time' => "Kama postviews OK! Execution time from PHP start: {$diff} sec.",
		'all_views_count' => $count->views_count,
		'month_views_count' => $count->prev_m_views_count,
		'out' => kpv_views_html( $count->views_count ) . ( $data->options->show_prev_m_views ? ' '. kpv_views_html( $count->prev_m_views_count, 'month' ) : '' ),
	] );
}

json_die( 'end', 'info' );




