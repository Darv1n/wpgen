<?php /** @noinspection AutoloadingIssuesInspection */

final class Count_Visit {

	public $views_count = 0;

	public $prev_m_views_count = 0;

	/**
	 * @var object $data {
	 *     @type int    $obj_id
	 *     @type string $obj_type
	 *     @type string $type_name
	 *     @type string $referrer
	 *     @type int    $user_id
	 *     @type object $options
	 * }
	 */
	private $data;

	public $skiped = false;

	private $wp_meta_table;
	private $meta_AND;
	private $last_log;
	private $cur_day_column;

	public function __construct( $data ){

		$this->data = $data;
	}

	/**
	 * Count visit based on passed parameters and write it to DB.
	 *
	 * @return void
	 */
	public function count_visit(){

		$this->check_log();

		if( $this->skiped ){
			return;
		}

		$this->add_update_wp_post_term_meta();

		$this->add_update_postviews_table();
	}

	private function check_log(){

		// check log
		$log_engine = new Log_Table_Engine( $this->data );
		$this->last_log = $log_engine->get_user_last_log();

		// check skip visit
		if(
			$this->last_log &&
			( kpv_cur_time('time') - strtotime( $this->last_log->log_time ) ) <= $this->data->options->hold_sec_between_counts
		){
			$this->skiped = true;
		}
		else {

			$log_engine->smart_clear_table(); // must be runned before any write into log table
			$log_engine->insert_user_log();
		}

	}

	private function add_update_postviews_table(){
		global $db;

		$data = $this->data;

		$db_obj_type = kpv_generate_db_obj_type( $data->obj_type, $data->type_name );

		$cur_yearmonth = kpv_cur_time('mysql_yearmonth');

		$this->cur_day_column = 'day_' . kpv_cur_time('j_day');

		$kpid = $db->get_var(
			"SELECT kpid FROM $db->postviews WHERE obj_id = ?i AND obj_type = ?s AND yearmonth = ?s",
			$data->obj_id, $db_obj_type, $cur_yearmonth
		);

		// update
		if( $kpid ){

			$db->query( "UPDATE $db->postviews SET views = (views + 1), $this->cur_day_column = ($this->cur_day_column + 1) WHERE kpid = $kpid" );

			if( ! $this->views_count ){
				$this->views_count = (int) $db->get_var(
					"SELECT SUM(views) FROM $db->postviews WHERE obj_id = ?i AND obj_type = ?s", $data->obj_id, $db_obj_type
				);
			}

			// get prev_m_views
			if( ! empty( $data->options->show_prev_m_views ) ){

				// у такс и записей получим предыдущее число просмотров из метаполя - туда умно записывается...
				if( $this->wp_meta_table ){
					$this->prev_m_views_count = (int) $db->get_var(
						"SELECT meta_value FROM $this->wp_meta_table WHERE meta_key = %s $this->meta_AND", KPV_PREV_MONTH_META_KEY
					);
				}
				else {
					//$date = new DateTime('now', new DateTimeZone("UTC") );
					//$date->modify( 'first day of -1 month' );
					//$prev_month = $date->format('Y-m-01');
					$prev_month = date( 'Y-m-01', strtotime('first day of -1 month') );

					$this->prev_m_views_count = (int) $db->get_var(
						"SELECT views FROM $db->postviews WHERE obj_id = ?i AND obj_type = ?s AND yearmonth = ?s",
						$data->obj_id, $db_obj_type, $prev_month
					);
				}
			}
		}
		// insert
		else {

			$db->insert( $db->postviews, [
				'obj_id'       => $data->obj_id,
				'obj_type'     => $db_obj_type,
				'yearmonth'    => $cur_yearmonth,
				'views'        => 1,
				$this->cur_day_column => 1,
			] );

			$kpid = $db->insert_id;

			if( ! $this->views_count ){
				$this->views_count = 1;
			}
		}

		// add / update META data
		if( $kpid ){

			$meta_key = $this->get_meta_key_by_referrer();

			if( $meta_key && $this->is_meta_key_allowed( $meta_key ) ){
				$this->add_postviews_meta( $kpid, $meta_key );
			}

			// unique visitor meta (one user unique will be written - ignore it)
			if( ! $this->last_log && $this->is_meta_key_allowed( 'unique' ) ){
				$this->add_postviews_meta( $kpid, 'unique' );
			}

			// mobile meta
			if( $this->is_meta_key_allowed( 'mobile' ) && is_mobile() ){
				$this->add_postviews_meta( $kpid, 'mobile' );
			}

		}

	}

	private function get_meta_key_by_referrer(){

		$referrer = explode( '?', $this->data->referrer )[0];

		if( ! $referrer ){
			return 'direct';
		}

		$meta_key = '';

		$referrer_patts = [
			'google'      => [ 'www.google.', '//google.' ],
			'yandex'      => 'yandex.',
			'zen_yandex'  => 'zen.yandex.', // zen.yandex.(ru|com|com.ua|...)
			'facebook'    => 'facebook.com',
			'vk'          => 'vk.com',
			'twitter'     => '//t.co',
			// at the end, because the internal link may contain a reference to the referrer:
			// https://site.ru/smes/?utm_referrer=https%3A%2F%2Fzen.yandex.com
			'inner'       => "//{$_SERVER['HTTP_HOST']}",
		];
		// 'other' we can calculate: all views minus sum of this

		foreach( $referrer_patts as $key => $patts ){

			foreach( (array) $patts as $patt ){

				if( strpos( $this->data->referrer, $patt ) ){
					$meta_key = $key;
					break 2;
				}
			}
		}

		return $meta_key;
	}

	private function add_update_wp_post_term_meta(){
		global $db;

		$data = $this->data;

		// add/update post/term WP meta table
		if( ! in_array( $data->obj_type, [ 'post', 'term' ] ) ){
			return;
		}

		if( 'post' === $data->obj_type ){
			$this->wp_meta_table = $db->prefix .'postmeta';
			$wp_meta_col = 'post_id';
			$this->meta_AND = "AND post_id = " . (int) $data->obj_id;
		}

		if( 'term' === $data->obj_type ){
			$this->wp_meta_table = $db->prefix .'termmeta';
			$wp_meta_col = 'term_id';
			$this->meta_AND = "AND term_id = " . (int) $data->obj_id;
		}

		// update
		if( $db->query( "UPDATE $this->wp_meta_table SET meta_value = ( meta_value + 1 ) WHERE meta_key = %s $this->meta_AND", KPV_META_KEY ) ){
			$this->views_count = (int) $db->get_var( "SELECT meta_value FROM $this->wp_meta_table WHERE meta_key = %s $this->meta_AND", KPV_META_KEY );
		}
		// add
		else {
			$db->insert( $this->wp_meta_table, [ $wp_meta_col => $data->obj_id, 'meta_key' => KPV_META_KEY, 'meta_value' => '1' ] );
			$this->views_count = 1;
		}

	}

	private function is_meta_key_allowed( $meta_key ){
		return $meta_key && in_array( $meta_key, $this->data->options->allowed_meta_keys, true );
	}

	/**
	 * Add +1 in views metadata.
	 *
	 * @param int    $kpid     Main id.
	 * @param string $meta_key Can be one of: `unique`, `direct`, `google`, `yandex`, `zen_yandex`, `facebook`, `vk`, `twitter`, `inner`.
	 */
	private function add_postviews_meta( $kpid, $meta_key ){
		global $db;

		$meta_key = preg_replace( '/[^a-zA-Z0-9_-]/', '', $meta_key );

		if( ! $meta_key ){
			return false;
		}

		// update
		$up = $db->query(
			"UPDATE $db->postviews_meta SET views = (views + 1), $this->cur_day_column = ($this->cur_day_column + 1) WHERE kpid = ?i AND meta_key = ?s",
			$kpid, $meta_key
		);

		// insert
		if( ! $up ){
			$up = $db->insert( $db->postviews_meta, [
				'kpid'         => $kpid,
				'meta_key'     => $meta_key,
				'views'        => 1,
				$this->cur_day_column => 1,
			] );
		}

		return $up;
	}

}