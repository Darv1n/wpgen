<?php

/**
 * Class to manage temporary log table. CRUD operations.
 */
final class Log_Table_Engine {

	/**
	 * @var object
	 */
	public $data;

	public function __construct( $data ){

		$this->data = (object) [
			'obj_id'      => (int) $data->obj_id,
			'obj_type'    => $data->obj_type,
			'type_name'   => $data->type_name,
			'user_id'     => (int) $data->user_id,
			'IP'          => (string) ( filter_var( @ $_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP ) ?: 'no_IP' ),
			'obj_id_type' => sprintf( '%s %s', $data->obj_id, kpv_generate_db_obj_type( $data->obj_type, $data->type_name ) ),
		];

	}

	/**
	 * Check and clear log table.
	 */
	public function smart_clear_table(){
		global $db;

		$clear_time = $this->clear_table_time( 'get' );

		if( ! $clear_time ){
			$this->clear_table_time( 'add' );
		}
		// clear every day
		elseif( explode( ' ', $clear_time )[0] !== kpv_cur_time('mysql_day') ){

			$db->query( "TRUNCATE TABLE $db->postviews_temp_log" );

			$this->clear_table_time( 'add' );
		}
	}

	/**
	 * @param string $action get|add
	 *
	 * @return string|FALSE|void Either first column of the first row of result-set or FALSE if none found.
	 */
	private function clear_table_time( $action ){
		global $db;

		$obj_id_type = 'table_cleared_time';

		if( 'get' === $action ){

			return $db->get_var( "SELECT log_time FROM $db->postviews_temp_log WHERE obj_id_type = '$obj_id_type'" );
		}

		if( 'add' === $action ){

			$db->insert( $db->postviews_temp_log, [
				'obj_id_type' => $obj_id_type,
				'log_time'    => kpv_cur_time('mysql'),
				'user_agent'  => 'This row is used for internal purpose to save time when this table was cleared last.',
			] );
		}
	}

	/**
	 * @return int
	 */
	public function insert_user_log(){
		global $db;

		return $db->insert( $db->postviews_temp_log, [
			'user_id'     => $this->data->user_id,
			'IP'          => $this->data->IP,
			'obj_id_type' => $this->data->obj_id_type,
			'log_time'    => kpv_cur_time('mysql'),
			'user_agent'  => $_SERVER['HTTP_USER_AGENT'],
		] );
	}

	/**
	 * @return object|null
	 */
	public function get_user_last_log(){

		$logs = $this->get_user_logs( [ 'limit' => 1 ] );

		return $logs ? reset( $logs ) : null;
	}

	/**
	 * Retrieve views log for object and user.
	 * User identifies by wp user_id or by IP if user not logged.
	 *
	 * @return array
	 */
	public function get_user_logs( $args = [] ){
		global $db;
		$data = $this->data;

		$LIMIT = $args['limit'] ? $db->parse( "LIMIT ?i", $args['limit'] ) : '';

		$ORDER_BY = 'ORDER BY log_time DESC';

		if( $data->user_id ){

			return $db->get_results(
				"SELECT * FROM $db->postviews_temp_log WHERE obj_id_type = ?s AND user_id = ?i $ORDER_BY $LIMIT",
				$data->obj_id_type, $data->user_id
			);
		}

		return $db->get_results(
			"SELECT * FROM $db->postviews_temp_log WHERE obj_id_type = ?s AND user_id = 0 AND IP = ?s $ORDER_BY $LIMIT",
			$data->obj_id_type, $data->IP
		);
	}

}
