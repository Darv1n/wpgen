=== Kama Postviews ===

Считает визиты на все тыпы страниц: записи (всех типов), таксономии (всех типов), главная, архивы, авторы и т.д. Заточен на работу с плагинами кэширования вроде WP Super Cache.



== Description ==

Считает визиты на все тыпы страниц: записи (всех типов), таксономии (всех типов), главная, архивы, авторы и т.д. Заточен на работу с плагинами кэширования вроде WP Super Cache.



== FAQ ==

#### Where the plugin writes the views counts?

For the posts it save the views in "views" custom field.
For taxonomy term it saves views in "views" tax custom field.


#### How to get views in my theme?

Plugin has two functions:

`<?php kpv_fresh_views( $id = 0, $type = '' ); ?>` - retriwe views meta field value and update it with javascript. Use it with cache plugins.

`<?php kpv_views( $id = 0, $type = '' ); ?>`  - retriwe views meta field value.

$id - ID of post/term.
$type - could be one of: 'post' or 'term'.

To get the values for use in PHP, add "get_" in front of function name: get_kpv_views(), get_kpv_fresh_views().

The alternative way to get views is to use standart WordPress functions:

`echo get_post_meta( $post_id, 'views', 1 );` - for post
`echo get_term_meta( $term_id, 'views', 1);` - for taxonomy term

#### Is the plugin counts visit of search robots?

NO! Any crawler robots missing from counting.



== Screenshots ==

No Screenshots yet



== Installation ==

#### Instalation via Admin Panel

1. Go to `Plugins > Add New > Search Plugins` enter "Kama Postviews"
2. Find the plugin in search results and install it.



== Changelog ==

= 3.5.8 =
- IMP: Отключение ненужных css и JS на фронте для не вошедших в пользователей.

= 3.5.7 =
- FIX: График в таксономиях в админке перемещен в самый низ.

= 3.5.6 =
- BUG: При сохранении опций.

= 3.5.5 =
- BUG: При установке константы KPV_META_KEY некоторые части кода не учитывали ее.
- BUG: Исправление ошибки парсера определения константы через 'const' в wp-config.php.
- IMP: Функции: kpv_fresh_views(), kpv_views() упразднены.
- IMP: Рефактор структуры кода.
- IMP: Незначительные улучшения.

= 3.5.4 =
- CSS стили в HEAD.
- Мелкие правки.

= 3.5.3 =
- Ошибка в последних обновлениях о подсчете мета-ключa `direct`.

= 3.5.2 =
- BUG: Правка бага с прошлого апдейта.

= 3.5.1 =
- Добавлена возможность не задавать диапазон дат для kpv_get_viewed_objects() (получить популярные за все вермя).
- Баги в переводах.
- Настройки: Скрыть "Удалить мета-данные", когда нет данных.
- Рефакторинг: функци count_visit() выенесена в класс Count_Visit{}. Апгрейтер. И многое другое.

= 3.5.0 =
- Новая логика, которая позволяет считать уникальных посетителей. Их можно увидеть в графике под меткой `unique`.
- Новая логика, которая позволяет считать посетителей с мобильных устройств. Их можно увидеть в графике под меткой `mobile`.
- Новая таблица в БД `postviews_temp_log` - хранит данные визитов за один текущий день (используется для внутренних рассчетов плагина).
- Новая опция "Разрешенные мета-данные", позволяет отключить подсчет для unique, mobile, direct, inner, google, yandex, facebook, vk, twitter.
- Новая опция "Цветовая схема графика", сейчас есть 2 цветовые гаммы.
- Новая опция "Задержка между подсчетами", позволяет указать минимальное кол-во секунд чтобы посчитать следующий просмотр отдельного пользователя.
- Новая опция "Удалите мета-данные", позволяет удалить все метаданные по ключу, если вдруг они стали не нужны (таким образом немного очищается БД).
- Новый хук `kama_postwiews__default_options` - позволяет изменить опции по умолчанию.
- Заменил jQuery ajax запрос на fetch(), таким образом убрал зависимость от jQuery.
- Префикс "не" для исключаемых от подсчета типов данных (с ним понятнее).
- Большой рефакторинг кода.
- Переводы.

= 3.4.3 =
- BUG: показ попапа чарта.

= 3.4.2 =
- BUG: Убрал зависимость от PHP расширения Calendar - `cal_days_in_month()`.

= 3.4.1 =
* Новый фильтр `kama_postviews__get_objects_clauses` позволяет изменить части запроса для получения объектов по кол-ву просмотров.

= 3.4.0 =
* NEW: Поддержка WP `meta_query` для параметра `$args` у функций: `kpv_get_popular_posts( $args )`, `kpv_get_popular_terms( $args )`, `kpv_get_viewed_objects( $args )`. См. https://wp-kama.ru/function/wp_meta_query. `meta_query` будет работать только для типов `post` или `term`.

= 3.3.11 =
* BUG: обновление "views_prev_month" - обновление мета-данных всегда запускалось, если мета-данных не было.

= 3.3.10 =
* IMP: Фильтры: `kama_postviews_obj_type`, `kama_postviews_obj_id`, заменены фильтром `kama_postviews__view_data`.

= 3.3.8 =
* BUG: Не работал подсчет если в пароле подключения к БД был знак `;`.

= 3.3.7 =
* NEW: хук `get_kpv_views`.
* IMP: Рефакторинг апгрейдера. Поддержка symlink (плагин не работал если папка плагинов в которую установлен плагин была символической ссылкой).

= 3.3.6 =
* BUG: Установил неправильную проверку obj_id и отвалился подсчет для главной и прочих страниц без ID.

= 3.3.5 =
* FIX: Удалил `get_magic_quotes_gpc()`.
* IMP: Проверка `$wp_config_found`.

= 3.3.2 =
* Мин поддержка php 5.4.
* Обертка для вывода HTML просмотров.
* CHG: изменил css класс `prev_m_views` на `prev-m-views` (надеюсь им никто не пользовался).

= 3.3.1 =
* Bug: в функции `kpv_get_viewed_objects()`. Немного переделал запрос.

= 3.3.0 =
* New: Функция `kpv_get_popular_terms()` такая же как `kpv_get_popular_posts()` только для терминов.
* Bug: в функции `kpv_get_viewed_objects()`.

= 3.2.11 =
* Bug: `kpv_exec_time()` некоторые сервера не поддерживают функции `bcadd()` или `bcsub()`, поэтому плагин переставал работать.

= 3.2.10 =
* Fix: Ошибка при создании SQL запроса для фукнции `kpv_get_popular_posts()`.

= 3.2.9.6 =
* UP: Обновление версии класса SafeMySQL
* Fix: Мелкие правки

= 3.2.9.3 =
* Fix: Динамическое определение высоты сетки чарта. И мелкие правки.

= 3.2.8.1 =
* Fix: Неверная ошибка 'error: no obj_id' во время ajax запроса...
* New: Обновление русской локализации...

= 3.2.8 =
* New: Теперь также можно фиксировать визиты на страницы архивов авторов.
* New: Возможность сортировать термины по визитам в таблице таксономий в админке.
* New: Теперь таблица List_table имеет две колонки: просмотры за пред.мес и все просмотры (обе сортируемые)
* New: Индексы у таблицы 'wp_postviews'
* New: Название фукнции `kap()` на `kpviews()`. Если вы используете эту фукнцию в коде вам придется заменить её название!
* New: Гораздо более удобный выбор (на странице опций) какие типы страниц нужно исключить из подсчета: опция `blocktypes`.
* New: Некоторые моменты в логике кода, для стабильной работы.
