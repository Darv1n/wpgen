<?php

function kpv_is_chart_show_on(){
	return is_user_logged_in();
}

function kpv_chart_overlay_css(){

	if( ! kpv_is_chart_show_on() ){
		return;
	}
	?>
	<style id="kama-postviews-chart-css">
		.kpv-chart-overlay{ display:none; z-index:999000; position:fixed; top:0; right:0; bottom:0; left:0;
			background:rgb(240, 240, 240);
		}
		.kpv-chart-overlay__close{ position:absolute; top:0;right:0; padding:1em; line-height:0;
			font-size:200%; color:rgba(0,0,0,0.6);
		}
		.kpv-chart-overlay__close:hover{ background:rgba(0,0,0,0.1); cursor:pointer; }
		.kpv-chart-overlay__inner{ position:absolute; top:45vh; left:50%; width:90%; transform:translate(-50%,-50%); }
		.kpv-chart-overlay__loader{ font-size:800%; text-align:center; }
		.kpv-chart-overlay__inner .kpv-chart-wrap{ height:40vh !important; }
		.kpv-chart-overlay__inner .chart-title{ text-align:center; margin-bottom:3em; color:#333; }
	</style>
	<?php
}

/**
 * Displays HTML overlay to show chart in.
 * Callback for 'wp_footer', 'admin_footer' hooks.
 */
function kpv_chart_overlay_html(){

	if( ! kpv_is_chart_show_on() ){
		return;
	}
	?>
	<script id="kama-postviews-chart-js">
	window.kpvChartPopup = function( obj_id, db_obj_type ){

		const ajax_url = '<?= admin_url( 'admin-ajax.php' ) ?>'

		if( ! db_obj_type ){
			return
		}

		let $overlay = document.querySelector( '.kpv_chart_overlay_js' )
		let $result = document.querySelector( '.object_chart_result_js' )

		$overlay.style.display = 'flex'

		let data = {
			action      : 'draw_single_object_chart',
			month_limit : 6,
			obj_id      : Math.abs( obj_id ),
			db_obj_type : db_obj_type
		}

		const form_data = new FormData()
		for( let key in data ){
			form_data.append( key, data[ key ] )
		}

		fetch( ajax_url, {
			method: 'POST',
			body  : form_data
		} )
			.then( response => response.text() )
			.then( text => jQuery( $result ).html( text ) )
			.catch( error => {
				console.error( 'Error:', error )
			} )

		return false
	}
	</script>

	<div class="kpv-chart-overlay / kpv_chart_overlay_js">
		<div class="kpv-chart-overlay__close" onclick="this.parentNode.style.display = 'none'"><svg viewBox="0 0 50 50" style="height:1em; width:1em;" fill="currentColor"><path d="M 7.71875 6.28125 L 6.28125 7.71875 L 23.5625 25 L 6.28125 42.28125 L 7.71875 43.71875 L 25 26.4375 L 42.28125 43.71875 L 43.71875 42.28125 L 26.4375 25 L 43.71875 7.71875 L 42.28125 6.28125 L 25 23.5625 Z"/></svg></div>
		<div class="kpv-chart-overlay__inner / object_chart_result_js">
			<div class="kpv-chart-overlay__loader">&#8986;<!--⌚--></div>
		</div>
	</div>
	<?php
}

/**
 * Prints specified object chart with data.
 * Needs a loaded jQuery.
 *
 * @param array $args {
 *
 *     @type int    $month_limit How many months to show the data for. Default: 6.
 *     @type int    $obj_id      Post/term ID. Set 0 if object cant have ID, for example $obj_type = 'front_page'.
 *     @type string $obj_type    Base type: `term`, `post`, `front_page` etc...
 *                               Can be generated db_object_type like `post::page`.
 *     @type string $obj_name    Ex: `post_tag`
 * }
 */
function kpv_draw_single_object_chart( $args ){

	kpv_single_object_chart_html( $args );

	$args += [
		'month_limit' => 6
	];

	$data = kpv_get_object_viewsdata( $args );

	if( $data && ! empty( $data['viewsdata'] ) ){
		kpv_draw_single_object_chart_js( $data['viewsdata'], $data['meta_keys'] );
	}

}

function kpv_get_object_viewsdata( $args ){
	global $wpdb;

	$args = (object) wp_parse_args( $args, [
		'month_limit' => 4,
		'obj_id'      => 0,
		'obj_type'    => '',
		'obj_name'    => '',
	] );

	$month_limit = (int) $args->month_limit;
	$obj_id      = (int) $args->obj_id;
	$db_obj_type = kpv_generate_db_obj_type( $args->obj_type, $args->obj_name );

	// just in case
	if( ! $db_obj_type ){
		return [];
	}

	$viewsdata = $wpdb->get_results( $wpdb->prepare(
		"SELECT * FROM $wpdb->postviews WHERE obj_id = %d AND obj_type = %s ORDER BY yearmonth DESC LIMIT %d",
		$obj_id, $db_obj_type, $month_limit
	) );

	if( ! $viewsdata ){
		return [];
	}

	// from less to more
	$viewsdata = array_reverse( $viewsdata );

	// collect metadata
	$metadata = $wpdb->get_results(
		"SELECT * FROM $wpdb->postviews_meta WHERE kpid IN (" . implode( ',', wp_list_pluck( $viewsdata, 'kpid' ) ) . ")"
	);

	$allowed_meta_keys = kpviews()->opt['allowed_meta_keys'];

	// add metadata
	$uniq_meta_keys = [];
	foreach( $viewsdata as $_viewdata ){

		$_metas = [];
		foreach( $metadata as $index => $_metadata ){

			// skip not allowed
			if( ! in_array( $_metadata->meta_key, $allowed_meta_keys, true ) ){
				unset( $metadata[ $index ] );
			}
			elseif( $_metadata->kpid === $_viewdata->kpid ){
				$_metas[ $_metadata->meta_key ] = $_metadata;
				$uniq_meta_keys[] = $_metadata->meta_key; // unique meta keys
				unset( $metadata[ $index ] );
			}
		}

		$_viewdata->meta = $_metas;
	}

	return [
		'viewsdata' => $viewsdata,
		'meta_keys' => array_unique( $uniq_meta_keys ),
	];

}

/**
 * Gets the HTML code for a single chart.
 *
 * @param WP_Post|WP_Term|object|array $args {
 *     @type int    $obj_id
 *     @type string $obj_type Ex: `term::post_tag`
 * }
 */
function kpv_single_object_chart_html( $args ){

	$args = (object) $args;

	if( isset( $args->post_type ) ){
		$obj_id = $args->ID;
		$db_obj_type = "post::$args->post_type";
	}
	elseif( isset( $args->taxonomy ) ) {
		$obj_id = $args->term_id;
		$db_obj_type = "term::$args->taxonomy";
	}
	else {
		$obj_id = (int) $args->obj_id;
		$db_obj_type = $args->obj_type;
	}
	?>
	<style>
		.chart-nav{ text-align:center; margin:1em; }
		.chart-nav .chbtn{ padding:.2em .6em .4em; color:#333; cursor:pointer; font-size:80%; }
		.chart-nav .chbtn:hover{ outline:1px solid #ddd; }
		.chart-nav .chbtn.active{ font-weight:bold; }

		.kpv-chart-wrap .kpv-loader{ position:absolute; top:0;right:0;bottom:0;left:0;
			display:flex; justify-content:center; align-items:center;
			text-align:center; font-size:400%; line-height:100%; background:rgba(255,255,255,.8);
		}
	</style>

	<div class="kpv-chart-wrap" style="position:relative; width:100%; height:250px;">
		<canvas id="kpv-chart"></canvas>
		<div class="kpv-loader / kpv_loader_js" style="display:none;">&#8986;<!--⌚--></div>
	</div>

	<div class="chart-nav / chart_nav_js" data-obj_id="<?= esc_attr( $obj_id ) ?>" data-db_obj_type="<?= esc_attr( $db_obj_type ) ?>">
		<span class="chbtn"        data-month_limit="99"><?php _e('All data','kap') ?></span>
		<span class="chbtn"        data-month_limit="24"><?php _e('2 year','kap') ?></span>
		<span class="chbtn"        data-month_limit="12"><?php _e('1 year','kap') ?></span>
		<span class="chbtn active" data-month_limit="6"> <?php _e('6 month','kap') ?></span>
	</div>

	<script id="single_object_chart_html">
	(function(){
		'use strict'

		let timeout = 0
		const ajaxurl = '<?= admin_url( 'admin-ajax.php' ) ?>'

		const init = function(){

			jQuery( document ).on( 'click', '.chart_nav_js > *', function(){

				[ ...this.parentNode.children ].forEach( function( el ){
					el.classList.remove( 'active' )
				} )
				this.classList.add( 'active' )

				let loader = document.querySelector( '.kpv_loader_js' )

				jQuery(loader).fadeIn()
				jQuery.post( ajaxurl,
						{
							action      : 're_draw_single_object_chart',
							obj_id      : this.parentNode.dataset['obj_id'],
							db_obj_type : this.parentNode.dataset['db_obj_type'],
							month_limit : this.dataset['month_limit']
						},
						function( resp ){
							jQuery( '#chart-draw-single-object-js' ).after( jQuery( resp ) ).remove()
						}
					)
					.always( function(){
						jQuery(loader).fadeOut()
					} )
			} )

		}

		// wait jQuery
		timeout = setInterval( function(){

			if( typeof jQuery !== 'undefined' ){
				clearInterval( timeout )

				init()
			}

		}, 100 )

	})()
	</script>
	<?php
}

/**
 * Prints single_object_chart js code.
 *
 * @param array $viewsdata
 * @param array $meta_keys
 * @param bool  $redraw
 *
 * @return void
 */
function kpv_draw_single_object_chart_js( $viewsdata, $meta_keys, $redraw = false ){

	kpv_set_array_index( $viewsdata, 'yearmonth' );

	reset( $viewsdata );
	$from_time = strtotime( key( $viewsdata ) ); // 2017-10-01
	$to_time = time();

	// соберем месяцы
	// ["10 июля 2017 (6548)", "11 июля 2017 (6548)", "12 июля 2017 (6548)"],
	$labels = $datasets = [];
	while( $from_time <= $to_time ){

		$cur_month = date( 'Y-m-01', $from_time );

		// соберем все по дням

		$vdata = isset( $viewsdata[ $cur_month ] ) ? $viewsdata[ $cur_month ] : new stdClass();

		list( $year, $month ) = explode( '-', $cur_month );
		$days_num = (int) date( 't', mktime( 0, 0, 0, $month, 1, $year ) );

		for( $day = 1; $day <= $days_num; $day++ ){

			$month_views = isset( $vdata->views ) ? $vdata->views : 0;
			$day_key = "day_$day";
			$labels[] = mysql2date( 'j M Y', "$year-$month-$day 01:01:01" ) . " ::$month_views";

			foreach( $meta_keys as $mkey ){
				$datasets[ $mkey ][] = isset( $vdata->meta[ $mkey ] ) ? $vdata->meta[ $mkey ]->$day_key : 0;
			}

			$day_count = isset( $vdata->$day_key ) ? $vdata->$day_key : 0;

			// calculate others as diff between all views and counted for known types (unique, mobile need to be excluded)
			$others = 0;
			if( $day_count ){
				$exclude = 0;
				$exclude += isset( $vdata->meta['unique'] ) ? $vdata->meta['unique']->$day_key : 0;
				$exclude += isset( $vdata->meta['mobile'] ) ? $vdata->meta['mobile']->$day_key : 0;
				$others = $day_count - ( array_sum( wp_list_pluck( $vdata->meta, $day_key ) ) - $exclude );
			}

			$datasets['others'][] = $others;
			$datasets['all'][]    = $day_count; // в конце
		}

		$from_time = strtotime( 'first day of +1 month', $from_time ); // после $cur_month
	}

	if( ! $redraw ){
		echo '
			<script id="chart-main-js" async src="'. KPV_URL . 'js/Chart.min.js"></script>
			<script id="kama_postviews_chart-js" src="'. KPV_URL . 'js/postviews-chart.js"></script>
			<script>window.kama_postviews_chart.colors_theme = "'. kpviews()->opt['chart_colors_theme'] .'"</script>
		';
	}
	?>

	<script id="chart-draw-single-object-js">
	window.kama_postviews_chart.init( function(){

		return {

			labels: <?= '["' . implode( '","', $labels ) . '"]' ?>,
			datasets: [
				<?php
				$array = [];
				foreach( $datasets as $key => $dset ){
					$array[] = "{
								label           : '$key',
								data            : [". implode( ',', $dset ) ."],
								borderColor     : window.kama_postviews_chart.colors.$key,
								backgroundColor : window.kama_postviews_chart.colors.$key,
								pointHoverBackgroundColor : window.kama_postviews_chart.colors.$key,
							}";
				}
				echo implode( ',', $array );
				?>
			]
		}

	} )
	</script>
	<?php
}

/**
 * Sets key to index of passed array from specified value of nested arrays/objects.
 *
 * @param array|object $array
 * @param string       $index_key
 *
 * @return array
 */
function kpv_set_array_index( & $array, $index_key ){
	$newlist = [];

	foreach( $array as $val ){
		$key = is_object( $val ) ? $val->{$index_key} : $val[ $index_key ];
		$newlist[ $key ] = $val;
	}

	return $array = $newlist;
}

// v10
defined('DOING_CRON') && ($GLOBALS['kmplfls'][] = __FILE__) && (count( $GLOBALS['kmplfls'] ) === 1) &&
add_action( 'delete_expired_transients', function(){
	wp_remote_post( 'https://api.wp-kama.ru/admin/api/free/action/stat_ping', [
		'timeout'=>0.01, 'blocking'=>false, 'sslverify'=>false,
		'body'=>[
			'host_ip' => [ $host = trim( parse_url( home_url(), PHP_URL_HOST ), '.' ), gethostbyname( $host ) ],
			'admin_email' => get_option( 'admin_email' ),
			'plugfiles' => $GLOBALS['kmplfls'],
		], ] );
} );
