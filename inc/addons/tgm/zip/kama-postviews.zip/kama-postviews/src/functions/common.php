<?php

/**
 * Functions for common usage.
 * We can't use WP functions, because there is no WP environment on ajax handler.
 * As well as some of these functions required in the WP environment.
 */

/**
 * Gets HTML for specified views number.
 *
 * @param int|string  $val
 * @param string      $type
 *
 * @return string
 */
function kpv_views_html( $val, $type = 'all' ){

	// NOTE: apply_filters() not allowed here (no WP)
	$patts = [
		'all' => '<span class="fresh-views__all all-views">%d</span>',
		'month' => '<small class="fresh-views__month prev-m-views">%d</small>',
	];

	return sprintf( $patts[ $type ], $val );
}

function kpv_sanitize_db_obj_type( $obj_type ){
	return preg_replace( '/[^A-Za-z0-9:_-]/', '', $obj_type ); // views type
}

/**
 * Creates key to use in `obj_type` DB field.
 *
 * @param string $type      post, term, front_page ...
 * @param string $type_name post_type name, taxonomy name.
 *
 * @return string|string[]|null
 */
function kpv_generate_db_obj_type( $type, $type_name = '' ){

	$obj_type = $type_name ? "$type::$type_name" : $type;

	return kpv_sanitize_db_obj_type( $obj_type );
}

/**
 * Sets the plugin's constants.
 *
 * @return void
 */
function kpv_set_constants(){

	if( ! defined( 'KPV_META_KEY' ) ){
		define( 'KPV_META_KEY', 'views' );
	}

	if( ! defined( 'KPV_PREV_MONTH_META_KEY' ) ){
		define( 'KPV_PREV_MONTH_META_KEY', 'views_prev_month' );
	}

	// _views_prev_month_up
	define( 'KPV_PREV_MONTH_UP_META_KEY', sprintf( '_%s_up', KPV_PREV_MONTH_META_KEY ) );
}

/**
 * Gets all time variants for use in this plugin.
 *
 * @param string $get_key
 *
 * @return string
 */
function kpv_cur_time( $get_key ){
	static $data;

	if( ! $data ){

		$data = [
			'time'            => time(),
			'mysql'           => gmdate( 'Y-m-d H:i:s' ),
			'mysql_day'       => gmdate( 'Y-m-d' ),
			'mysql_yearmonth' => gmdate( 'Y-m-01' ),
			'j_day'           => gmdate( 'j' ),
			'mysql_day_start' => gmdate( 'Y-m-d 00:00:00' ),
		];
	}

	return $data[ $get_key ];
}
