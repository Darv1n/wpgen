<?php

/**
 * Init plugin or gets current Kama_Postviews instance.
 *
 * @return Kama_Postviews
 */
function kpviews(){
	static $instance;

	if( ! $instance ){
		$instance = new Kama_Postviews();
	}

	return $instance;
}

/**
 * Получает количество просмотров и обновляет значение при просмотре (через AJAX).
 *
 * @param  integer $id   Object ID: post_id, term_id ...
 * @param  string  $type Object type: post, term, front_page ...
 * @return string  HTML
 */
function get_kpv_fresh_views( $id = 0, $type = '' ){
	return '<span class="fresh-views fresh_views_js">'. get_kpv_views( $id, $type ) .'</span>';
}

/**
 * Gets post/term views count in HTML tag.
 *
 * @param int    $id         Post or Term ID. Default: 0 (current post/term).
 *                           Default: 0 (current post).
 * @param string $type       Type ID of which was passed in $id parameter. Can be: 'term', 'post'.
 *                           Default: '' (current queried object type).
 * @param bool $use_html     True - returns data in HTML tag.
 *                           False - returns raw views data (integers separated with comma).
 *                           null - allows change it using filter.
 *                           Default: true.
 *
 * @return string Количество просмотров.
 */
function get_kpv_views( $id = 0, $type = '', $use_html = null ){

	if( null === $use_html ){

		/**
		 * Allows to set $use_html through hook.
		 *
		 * @param bool $use_html
		 */
		$use_html = apply_filters( 'get_kpv_views__use_html_default', true );
	}

	$out = kpv_get_object_views_data( $id, $type );

	$sep = ', ';
	if( $use_html ){
		$out['all'] = kpv_views_html( $out['all'] );
		$out['month'] = kpv_views_html( $out['month'], 'month' );
		$sep = ' ';
	}

	if( ! kpviews()->opt['show_prev_m_views'] ){
		unset( $out['month'] );
	}

	$out = implode( $sep, $out );

	/**
	 * Allows to change get_kpv_views() output.
	 *
	 * @param string $out  Out string.
	 * @param int    $id   Post/term id.
	 * @param string $type 'post' or 'term'.
	 */
	return apply_filters( 'get_kpv_views', $out, $id, $type );
}

/**
 * Gets post or term views data.
 *
 * @param int    $obj_id     Post or Term ID. Default: 0 (current post/term).
 *                           Default: 0 (current post).
 * @param string $obj_type   Type ID of which was passed in $id parameter. Can be: 'term', 'post'.
 *                           Default: '' (current queried object type).
 *
 * @return array Views count for `month` or `all`.
 */
function kpv_get_object_views_data( $obj_id = 0, $obj_type = '' ){

	if( ! $obj_type ){
		if( in_the_loop() ){
			$obj_type = 'post';
		}
		else {
			$queri = get_queried_object();

			isset( $queri->term_id ) && $obj_type = 'term';
			isset( $queri->post_type ) && $obj_type = 'post';
		}
	}

	if( 'post' === $obj_type ){

		if( ! $obj_id ){
			$obj_id = $GLOBALS['post']->ID;
		}

		$all = get_post_meta( $obj_id, KPV_META_KEY, true );
		$month = get_post_meta( $obj_id, KPV_PREV_MONTH_META_KEY, true );
	}
	elseif( 'term' === $obj_type ){

		if( ! $obj_id ){
			$obj_id = (int) get_queried_object()->term_id;
		}

		$all = get_term_meta( $obj_id, KPV_META_KEY, true );
		$month = get_term_meta( $obj_id, KPV_PREV_MONTH_META_KEY, true );
	}

	return [
		'all' => (int) $all,
		'month' => (int) $month,
	];

}

/**
 * Получает объекты постов отсортированные по просмотрам.
 * Работает на базе `kpv_get_viewed_objects()`, и принимает те же параметры.
 *
 * @param array $args Смотрите параметры `kpv_get_viewed_objects()`
 *
 * @return array  Массив Постов или пустой массив, когда посты не найдены.
 */
function kpv_get_popular_posts( $args ){

	// @see kpv_get_viewed_objects() parameters
	$rg = (object) wp_parse_args( $args, [
		'type'      => 'post',
		'post_type' => 'post',
		'limit'     => 10,
	] );

	$objects = kpv_get_viewed_objects( $rg );

	if( ! $objects ){
		return [];
	}

	$posts = get_posts( [
		'post_type' => $rg->post_type,
		'include'   => array_keys( $objects ),
		//'numberposts', // ставится через include
		'orderby'   => 'post__in',
	] );

	// add views
	foreach( $posts as $pst ){
		$pst->views = $objects[ $pst->ID ]->views;
	}

	return $posts;
}

/**
 * Получает объекты терминов (элементов таксономий) отсортированные по просмотрам.
 * Работает на базе `kpv_get_viewed_objects()`, и принимает те же параметры.
 *
 * @param  array  $args   Смотрите параметры `kpv_get_viewed_objects()`.
 *
 * @return array  Массив объектов WP_Term или пустой массив, когда посты не найдены. См. `get_terms()`.
 */
function kpv_get_popular_terms( $args ){

	// @see kpv_get_viewed_objects() parameters
	$rg = (object) wp_parse_args( $args, [
		'type'     => 'term',
		'taxonomy' => 'category',
		'limit'    => 10,
	] );

	if( ! $objects = kpv_get_viewed_objects( $rg ) )
		return [];

	$terms = get_terms( [
		'taxonomy' => $args->taxonomy,
		'include'  => array_keys( $objects ),
		'orderby'  => 'include',
	] );

	// add views
	foreach( $terms as $term ){
		$term->views = $objects[ $term->term_id ]->views;
	}

	return $terms;
}

/**
 * Получает самые просматриваемые записи (или другие типы) за указанный период времени и сортирует их по просмотрам.
 * В датах нужно передавать время в UTC (GMT), а не локальное время сайта.
 *
 * @param array|object|string $args {
 *     Масив или строка параметров.
 *
 *     @type string  $type       Тип получаемых данных. Может быть: post, term, front_page, search, 404, post_type_archive, year, month, day.
 *     @type string  $post_type  Название типа записи, если $type = post. По умолчанию: post.
 *     @type string  $taxonomy   Название таксономии, если $type = term. По умолчанию: category.
 *     @type string  $for_range  Период за который нужно получить популярные посты. Формат: 2017-08-01,2017-09-16.
 *                               Если указать одну дату, то след. дата будет текущая.
 *                               Вместо любой даты можно указать относительный формат: http://de2.php.net/manual/ru/datetime.formats.relative.php
 *                               Примеры относительного формата:
 *                               'today', 'yesterday', '-2 day' или '2 days ago', '-2 month' или '2 months ago', 'first day of -2 month'.
 *                               Не обязательный. По умолчанию: ''
 *     @type string  $for_day    День за который нужно получить популярные объекты (посты, термины). Формат: 2017-08-01.
 *                               Можно указать относительный формат.
 *                               Не обязательный. По умолчанию: ''
 *     @type string  $for_month  Месяц за который нужно получить популярные объекты. Формат: 2017-08 или 2017-08-xx.
 *                               Можно указать относительный формат.
 *                               Не обязательный. По умолчанию: ''
 *     @type array   $object_ids ID объектов (постов, терминов, юзеров) из которых нужно делать выборку.
 *     @type array   $exclude    ID объектов (постов, терминов, юзеров) которые нужно исключить из выборки.
 *     @type string  $limit      Сколько объектов получать. По умолчанию 20.
 *     @type string  $order      Как сортировать. По умолчанию DESC - популярные вверху.
 * }
 *
 * @return array  Массив с ключами [obj_id, views] или пустой массив, если не удалось получить результаты.
 */
function kpv_get_viewed_objects( $args = [] ){
	global $wpdb;

	static $last_sql = '';

	if( 'get_last_sql' === $args ){
		return preg_replace( '/^\t+/m', '', trim( $last_sql ) );
	}

	$allowed_args = [
		'type'       => 'post',
		'post_type'  => 'post',
		'taxonomy'   => 'category',
		'for_range'  => '',
		'for_day'    => '',
		'for_month'  => '',
		'object_ids' => [],
		'exclude'    => [],
		'limit'      => 20,
		'order'      => 'DESC',
	];

	/**
	 * Allows to change query arguments.
	 *
	 * @param array $args
	 *
	 * @since 3.4.0
	 *
	 */
	$args = apply_filters( 'kama_postviews__get_objects_args', wp_parse_args( $args, $allowed_args ) );

	$rg = (object) $args; // оставим только разрешенные

	// sanitize
	foreach( $rg as $name => & $_val ){

		if( is_string( $_val ) ){
			$_val = trim( $_val );
		}

		if( 'object_ids' === $name ){
			$_val = array_map( 'intval', (array) $_val );
		}
		elseif( 'exclude' === $name ){
			$_val = array_map( 'intval', (array) $_val );
		}
		elseif( 'limit' === $name ){
			$_val = (int) $_val;
		}
		elseif( 'order' === $name ){
			$_val = ( $_val === 'DESC' ? 'DESC' : 'ASC' );
		}
		elseif( in_array( $name, [ 'type', 'post_type', 'taxonomy' ] ) ){
			$_val = sanitize_key( $_val );
		}
		else{
			$_val = sanitize_text_field( $_val ); // простая очистка
		}
	}
	unset( $_val );

	// strtotime( '2017-11-24' ) > 2017-11-24 12:00:00
	// strtotime( '2017-11' )    > 2017-11-01 12:00:00

	// собираем $dates_array
	/*
	$dates_array = Array(
		[2017-07-01] => Array
				[0] => day_26
				[1] => day_27
				[2] => day_28
				[3] => day_29
				[4] => day_30
				[5] => day_31

		[2017-08-01] => all
		[2017-09-01] => all
		[2017-10-01] => all
		[2017-11-01] => Array
				[0] => day_1
				[1] => day_2
				[2] => day_3
				[3] => day_4
				[4] => day_5
	)
	*/

	$dates_array = [];

	// вспомогательная функция
	$add_day_to_dates_array__fn = static function( $day_time ) use ( & $dates_array ){

		if( $day_time ){
			$day_date = date( 'Y-m-d', $day_time );
			// оставим только число дня и уберем лидирующий ноль...
			$dates_array[ substr( $day_date, 0, -3 ) . '-01' ][] = 'day_' . (int) substr( $day_date, 8 );
		}
	};

	if( $rg->for_day ){
		$add_day_to_dates_array__fn( strtotime( $rg->for_day ) );
	}
	elseif( $rg->for_month ){

		if( $month_time = strtotime( $rg->for_month ) ){
			$dates_array[ date( 'Y-m-01', $month_time ) ] = 'all';
		}
	}
	elseif( $rg->for_range ){

		$range = preg_split( '/\s*,\s*/', $rg->for_range );
		$range = array_map( 'trim', $range );
		$from_time = empty( $range[0] ) ? time() : strtotime( $range[0] );
		$to_time = empty( $range[1] ) ? time() : strtotime( $range[1] );

		if( $from_time && $to_time ){

			// $days_in_month = date( 't', $from_time ); // количество дней в месяце - это учитывается в while
			while( $to_time >= $from_time ){
				$add_day_to_dates_array__fn( $from_time );

				$from_time += DAY_IN_SECONDS;
			}

			// очистим месяцы заполненные полностью...
			foreach( $dates_array as $month_key => $days ){
				// если дней в месяце столько же сколько в массиве дней, то это полный месяц, поэтому чистим дни.
				if( (int) date( 't', strtotime( $month_key ) ) === count( $days ) ){
					$dates_array[ $month_key ] = 'all'; // чистим
				}
			}
		}
	}

	// на основе $dates_array ---

	// собираем запрос
	$obj_type = $rg->type;

	// WP META sql clauses
	$meta_JOIN = $meta_WHERE = '';
	if( in_array( $obj_type, [ 'post', 'term' ], 1 ) ){

		$mq_obj = new WP_Meta_Query();
		$mq_obj->parse_query_vars( $args );
		$mq_sql = $mq_obj->get_sql( $obj_type, 'temp_table', 'obj_id' );

		if( $mq_obj->get_clauses() ){
			$meta_JOIN = $mq_sql['join'];
			$meta_WHERE = $mq_sql['where']; // contains begining AND
		}
	}

	if( 'post' === $obj_type ){

		if( ! $rg->post_type ){
			$rg->post_type = 'post';
		}

		$obj_type = "post::$rg->post_type";
	}

	if( 'term' === $obj_type ){

		if( ! $rg->taxonomy ){
			$rg->taxonomy = 'category';
		}

		$obj_type = "term::$rg->taxonomy";
	}

	$clauses = [
		'found_rows' => '',
		'distinct'   => '',
		'fields'     => 'obj_id, SUM(views) as views_',
		'join'       => $meta_JOIN,
		'where'      => "views > 0 $meta_WHERE",
		'groupby'    => 'GROUP BY obj_id',
		'orderby'    => "ORDER BY views_ $rg->order",
		'limits'     => $rg->limit ? $wpdb->prepare( 'LIMIT %d', $rg->limit ) : '',
	];

	/**
	 * Allows to change kama postviews get objects sql query clauses at once.
	 *
	 * Covers the WHERE, GROUP BY, JOIN, ORDER BY, DISTINCT,
	 * fields (SELECT), and LIMITS clauses.
	 *
	 * @param string[] $clauses  Associative array of the clauses for the query.
	 * @param array    $args     Passed arguments.
	 *
	 * @since 3.4.1
	 *
	 */
	$clauses = (object) apply_filters( 'kama_postviews__get_objects_clauses', $clauses, $args );

	$main_sql_patt = "
		SELECT $clauses->found_rows $clauses->distinct $clauses->fields 
		FROM {{TABLE}} $clauses->join 
		WHERE $clauses->where {{WHERE}}
		$clauses->groupby 
		$clauses->orderby 
		$clauses->limits
	";


	// WHERE condition that uses for current temp_table
	$inner_WHERE = [];

	// obj_type WHERE
	$inner_WHERE[] = $wpdb->prepare( "obj_type = %s", $obj_type );

	// obj_id WHERE
	if( $rg->object_ids ){
		$inner_WHERE[] = 'obj_id IN (' . implode( ',', $rg->object_ids ) . ')';
	}
	elseif( $rg->exclude ){
		$inner_WHERE[] = 'obj_id NOT IN (' . implode( ',', $rg->exclude ) . ')';
	}

	if( $dates_array ){

		/** варианты запросов
		 *
		 * // за месяц
		 * SELECT obj_id, SUM(views) as views_ FROM (
		 * SELECT obj_id, views as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth IN ( '2017-11-01'б '2017-12-01' )
		 * ) temp_table
		 * WHERE views > 0 GROUP BY obj_id ORDER BY views_ DESC LIMIT 50
		 *
		 * // за день
		 * SELECT obj_id, SUM(views) as views_ FROM (
		 * SELECT obj_id, ( day_25 ) as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth = '2017-07-01'
		 * ) temp_table
		 * WHERE views > 0 GROUP BY obj_id ORDER BY views_ DESC LIMIT 50
		 *
		 * // комбинация двух предыдущих запросов
		 * // собираем сумму где начало из дней (конечных), потом полностью месяцы, потом конец из дней (начальных)
		 * SELECT obj_id, SUM(views) as views_ FROM
		 * (
		 * SELECT obj_id, ( day_29 + day_30 ) as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth = '2017-09-01'
		 * UNION ALL
		 * SELECT obj_id, ( day_1 + day_2 ) as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth = '2017-11-01'
		 * UNION ALL
		 * SELECT obj_id, views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth IN ( '2017-10-01' )
		 * ) temp_table
		 * WHERE views > 0 GROUP BY obj_id ORDER BY views_ DESC LIMIT 50
		 */

		$temp_TABLE__fn = static function( $views_SUM, $inner_WHERE ) use ( $wpdb ){

			$WHERE = 'WHERE ' . implode( ' AND ', $inner_WHERE );

			return "( SELECT obj_id, $views_SUM as views FROM $wpdb->postviews $WHERE ) temp_table";
		};

		// только месяцы - в массиве только all
		$is_dates_array_only_all = true;
		foreach( $dates_array as $val ){
			if( $val !== 'all' ){
				$is_dates_array_only_all = false;
				break;
			}
		}

		// все дни месяца
		if( $is_dates_array_only_all ){
			$views_SUM = 'views';
			$inner_WHERE[] = "yearmonth IN ( '" . implode( "','", array_keys( $dates_array ) ) . "' )";

			$TABLE = $temp_TABLE__fn( $views_SUM, $inner_WHERE );
		}
		// несколько дней одного месяца
		elseif( count( $dates_array ) === 1 ){
			$views_SUM = '( ' . implode( ' + ', reset( $dates_array ) ) . ' )';
			$inner_WHERE[] = "yearmonth = '" . esc_sql( key( $dates_array ) ) . "'";

			$TABLE = $temp_TABLE__fn( $views_SUM, $inner_WHERE );
		}
		// месяцы и дни
		// несколько дней одного месяца
		// UNION ALL
		else{

			/*
			(
				SELECT obj_id, (day_28 + day_29 + day_30) as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth = '2017-05-01' -- ;
				 UNION ALL
				SELECT obj_id, views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth IN ( '2017-06-01', '2017-07-01', '2017-08-01' ) -- ;
				 UNION ALL
				SELECT obj_id, (day_1 + day_2 + day_3) as views FROM wp_postviews WHERE obj_type = 'post::func' AND yearmonth = '2017-09-01' -- ;
			) temp_table
			*/

			$SELECTS = $monthes_keys = [];
			foreach( $dates_array as $month_key => $days ){

				if( $days === 'all' ){
					$monthes_keys[] = $month_key;
				}
				else{
					$_views_SUM = "( " . implode( ' + ', $days ) . " )";
					$_inner_WHERE = $inner_WHERE;
					$_inner_WHERE[] = "yearmonth = '" . esc_sql( $month_key ) . "'";

					$SELECTS[] = "SELECT obj_id, $_views_SUM as views FROM $wpdb->postviews WHERE " . implode( ' AND ', $_inner_WHERE );
				}
			}

			// all month
			if( $monthes_keys ){
				$inner_WHERE[] = "yearmonth IN ( '" . implode( "','", array_map( 'esc_sql', $monthes_keys ) ) . "' )";

				$SELECTS[] = "SELECT obj_id, views FROM $wpdb->postviews WHERE " . implode( ' AND ', $inner_WHERE );
			}

			$TABLE = "(\n" . implode( "\n UNION ALL \n", $SELECTS ) . "\n) temp_table";
		}


		// save to $last_sql
		$main_sql_patt = str_replace( '{{WHERE}}', '', $main_sql_patt );
		$last_sql = str_replace( '{{TABLE}}', "\n$TABLE\n", $main_sql_patt );
	}
	else {

		$TABLE = $wpdb->postviews;
		$main_sql_patt = str_replace( '{{TABLE}}', $TABLE, $main_sql_patt );
		$last_sql = str_replace( '{{WHERE}}', ' AND '. implode( ' AND ', $inner_WHERE ), $main_sql_patt );
	}

	$result = $wpdb->get_results( $last_sql, OBJECT_K );

	// change `views_` back to `views`
	foreach( $result as $res ){
		$res->views = $res->views_;
		unset( $res->views_ );
	}

	return $result;
}


// LEGACY

/**
 * Display the get_kpv_fresh_views() result.
 *
 * @deprecated 3.5.5 Use `echo get_kpv_fresh_views()`.
 *
 * @param int    $id
 * @param string $type
 */
function kpv_fresh_views( $id = 0, $type = '' ){
	echo get_kpv_fresh_views( $id, $type );
}

/**
 * Выводит на экран. Обертка для get_kpv_views().
 *
 * @deprecated 3.5.5 Use `echo get_kpv_views()`.
 *
 * @param int    $id
 * @param string $type
 */
function kpv_views( $id = 0, $type = '' ){
	echo get_kpv_views( $id, $type );
}

function fresh_kap_views()    {  return kpv_fresh_views( ...func_get_args() );  }
function get_fresh_kap_views(){  return get_kpv_fresh_views( ...func_get_args() );  }
function kap_views()          {  return kpv_views( ...func_get_args() );  }
function get_kap_views()      {  return get_kpv_views( ...func_get_args() );  }






