<?php

class Kama_Postviews {

	const OPT_NAME = 'kama_postviews';

	/**
	 * @var \Kama_Postviews\Admin\Kama_Postviews_Admin
	 */
	public $admin;

	/**
	 * @var array
	 */
	public $opt;

	public function __construct(){

		$this->set_options();

		\Kama_Postviews\Upgrade\Kama_Postviews_Upgrade::init();

		$this->add_wp_hooks();

		if( is_admin() ){
			$this->admin = new \Kama_Postviews\Admin\Kama_Postviews_Admin();
		}
	}

	public function __get( $name ){

		if( 'OPT_NAME' === $name ){
			return self::OPT_NAME;
		}

		return null;
	}

	private function set_options(){

		$this->opt = get_option( self::OPT_NAME, [] );

		foreach( $this->default_options() as $name => $val ){

			if( ! isset( $this->opt[ $name ] ) ){
				$this->opt[ $name ] = $val;
			}
		}

		// fixes

		if( 'all' === $this->opt[ 'allowed_meta_keys' ] ){
			$this->opt[ 'allowed_meta_keys' ] = array_keys( $this->meta_keys_data() );
		}

	}

	private function add_wp_hooks(){

		if( ! is_admin() ){
			add_action( 'wp_head', 'kpv_chart_overlay_css' );
			add_action( 'wp_footer', 'kpv_chart_overlay_html' );
			add_action( 'admin_bar_menu', [ $this, '_add_toolbar_link' ], 240 );

			add_action( 'wp_footer', [ $this, '_smart_jquery_enqueue' ], -1 ); // -1 !important
			add_action( 'wp_head',   [ $this, 'echo_init_count_js' ], 99 );
		}

		// Delete object data from kap_table on term/post/attachment/author delete
		add_action( 'deleted_post', [ __CLASS__, '_delete_views_data_by_hookname' ] );
		add_action( 'delete_term',  [ __CLASS__, '_delete_views_data_by_hookname' ] );
		add_action( 'deleted_user', [ __CLASS__, '_delete_views_data_by_hookname' ] );

		// ajax
		add_action( 'wp_ajax_'.'draw_single_object_chart', [ \Kama_Postviews\Ajax\Chart::class, 'draw_single_object_chart' ] );
		add_action( 'wp_ajax_'.'re_draw_single_object_chart', [ \Kama_Postviews\Ajax\Chart::class, 're_draw_single_object_chart' ] );
	}

	public function meta_keys_data(){

		return [
			'unique'     => __( '`unique` — count Unique visitors.', 'kap' ),
			'mobile'     => __( '`mobile` — count visitors came with Mobile device.', 'kap' ),
			'direct'     => __( '`direct` — count visitors came on the page Directly (by referrer).', 'kap' ),
			'inner'      => __( '`inner` — count visitors came from the site internal page (by referrer).', 'kap' ),
			'google'     => __( '`google` — count visitors came from Google (by referrer).', 'kap' ),
			'yandex'     => __( '`yandex` — count visitors came from Yandex (by referrer).', 'kap' ),
			'zen_yandex' => __( '`zen_yandex` — count visitors came from zen.yandex.(ru|com|...) (by referrer).', 'kap' ),
			'facebook'   => __( '`facebook` — count visitors came from Facebook (by referrer).', 'kap' ),
			'vk'         => __( '`vk` — count visitors came from Vkontakte (by referrer).', 'kap' ),
			'twitter'    => __( '`twitter` — count visitors came from Twitter (by referrer).', 'kap' ),
		];
	}

	/**
	 * @return array {
	 *     Options [ key => value ] pairs.
	 *
	 *     @type string $who_count               Чьи посещения считать?
	 *                                           `all` - Всех. not_logged_users - Только гостей.
	 *                                           `logged_users` - Только авторизованных пользователей.
	 *                                           `not_admins` - Всех, кроме админов.
	 *                                           `not_admins_and_authors` - Всех, кроме админов и авторов записей.
	 *     @type int    $hold_sec                Задержка в секундах перед тем как запустится подсчет.
	 *     @type int    $hold_sec_between_counts Задержка в секундах между подсчетами визита отдельного пользователя.
	 *     @type array  $blocktypes              Какие типы страниц нужно убрать из подсчета. Возможные элементы массива:
	 *                                           'post', 'term', '404', 'year', 'month', 'day', 'front_page', 'home',
	 *                                           'search', 'author', 'post_type_archive', 'taxonomy_name', 'post_type_name'.
	 *     @type int    $show_prev_m_views       Показывать ли визиты за предыдущий месяц при показе визитов функцией.
	 *     @type int    $allowed_meta_keys       null — allow all
	 *     @type string $chart_colors_theme
	 * }
	 */
	public function default_options(){

		$options = [
			'who_count'               => 'not_admins_and_authors',
			'hold_sec'                => 2,
			'hold_sec_between_counts' => 10,
			'blocktypes'              => [ 'attachment', 'author', 'year', 'month', 'day', 'post_format' ],
			'show_prev_m_views'       => 1,
			'allowed_meta_keys'       => 'all',
			'chart_colors_theme'      => 'tomorrow_soft',
		];

		/**
		 * Allows filter default options.
		 *
		 * @param array $options
		 */
		return apply_filters( 'kama_postwiews__default_options', $options );
	}

	public function _add_toolbar_link( $wp_admin_bar ){

		$data = $this->get_query_obj_data();

		if( ! $data->obj_type )
			return;

		$db_obj_name = kpv_generate_db_obj_type( $data->obj_type, $data->type_name );

		$wp_admin_bar->add_menu( [
			'id'    => 'chartlink',
			'title' => '<span class="ab-icon dashicons-visibility"></span><span class="ab-label">'. __('Views','kap') .'</span>',
			'href'  => '#',
			'meta'  => [
				'onclick' => sprintf( 'window.kpvChartPopup( %s, "%s" ); return false;', $data->obj_id, $db_obj_name ),
			],
		] );
	}

	public function _smart_jquery_enqueue(){

		if( ! wp_script_is( 'jquery', 'enqueued' ) ){
			wp_enqueue_script( 'jquery' );
		}
	}

	public function echo_init_count_js(){
		global $post;

		$show_js = false;
		switch( $this->opt['who_count'] ){

			case 'all':
				$show_js = true;
				break;

			case 'not_logged_users':
				if( ! is_user_logged_in() ){
					$show_js = true;
				}
				break;

			case 'logged_users':
				if( is_user_logged_in() ){
					$show_js = true;
				}
				break;

			case 'not_admins':
				if( ! current_user_can( 'manage_options' ) ){
					$show_js = true;
				}
				break;

			case 'not_admins_and_authors':
				if( ! current_user_can( 'manage_options' ) ){
					$show_js = true;
				}

				// not count visit author of a post to the post
				if( is_singular() && is_user_logged_in() && (int) $post->post_author === (int) get_current_user_id() ){
					$show_js = false;
				}
				break;

		}

		// not count drafts
		if( is_preview() ){
			$show_js = false;
		}

		/**
		 * Allows you to add base counting javascript forcibly
		 * when it hasn't passed all the checks to be included.
		 *
		 * @param bool $force_show_js Whether show count js forcibly.
		 */
		if( apply_filters( 'kama_postviews_force_show_js', false ) ){
			$show_js = true;
		}

		// not count.
		if( ! $show_js ){
			return;
		}

		$data = $this->get_query_obj_data();

		/**
		 * Allow to change the defined counting data.
		 * You can add/set your own counting data to count any non-standard pages visits.
		 *
		 * @param object $data {
		 *     Data to be used for determine current page during counting the visit.
		 *
		 *     @type int    $obj_id    Current counting object ID. Ex: post id.
		 *                             Set 0 if the page have no ID ($obj_type must be unique in this case).
		 *     @type string $obj_type  Current counting object type. Ex: post, term, or custom type.
		 *     @type string $type_name Additional correction for type. Ex: post type, term taxonomy or empty string.
		 * }
		 */
		$data = apply_filters( 'kama_postviews__view_data', $data );

		if( ! $data || empty( $data->obj_type ) ){
			return;
		}

		$this->update_meta__views_prev_month( $data );

		if( 'detect rel path to the `wp-config.php` rel to `DOCUMENT_ROOT`' ){

			/*
			 * Find wp-config.php directory
			 * If wp-config.php exists in the WordPress root, or if it exists in the root and wp-settings.php
			 * doesn't, load wp-config.php. The secondary check for wp-settings.php has the added benefit
			 * of avoiding cases where the current directory is a nested installation, e.g. / is WordPress(a)
			 * and /blog/ is WordPress(b).
			 */
			$wpconfig_dir = $_wpconfig_reldir = null;

			if( @file_exists( ABSPATH . 'wp-config.php' ) ){
				$wpconfig_dir = untrailingslashit( wp_normalize_path( ABSPATH ) );
			}
			elseif(
				@file_exists( dirname( ABSPATH ) . '/wp-config.php' )
				&&
			    ! @file_exists( dirname( ABSPATH ) . '/wp-settings.php' )
			){
				$wpconfig_dir = wp_normalize_path( dirname( ABSPATH ) );
			}

			if( $wpconfig_dir ){

				$DROOT = untrailingslashit( wp_normalize_path( $_SERVER['DOCUMENT_ROOT'] ) );

				$relpath = str_replace( $DROOT, '', $wpconfig_dir, $count );

				// only if str_replace() done
				if( $count ){
					$_wpconfig_reldir = ( '' === $relpath ? '/' : $relpath );
				}
			}
		}

		$options = (object) [
			'show_prev_m_views'       => $this->opt['show_prev_m_views'],
			'_wpconfig_droot_relpath' => $_wpconfig_reldir ?: '',
			'hold_sec_between_counts' => $this->opt['hold_sec_between_counts'],
			'allowed_meta_keys'       => implode( ',', $this->opt['allowed_meta_keys'] ),
		];

		$data->options = $options;

		ob_start();

		?>
		<script>
		setTimeout(
			function(){
				let url = '<?= KPV_URL . 'ajax-count-handler/zero.php' ?>'
				let data = {
					obj_type : '<?= $data->obj_type ?>',
					type_name: '<?= $data->type_name ?>',
					obj_id   : '<?= $data->obj_id ?>',
					referrer : ('referrer' in document) ? document.referrer : '',
					user_id  : <?= is_user_logged_in() ? get_current_user_id() : 0 ?>,
					options  : '<?= json_encode( $data->options ) ?>'
				}

				fetch( url, {
					method : 'POST',
					headers: { 'Content-Type': 'application/json; charset=UTF-8' },
					body   : JSON.stringify( data )
				} )
					.then( resp => resp.json() )
					.then( json => {
						if( 'error' === json.type ){
							console.error( `ERROR: ${ json.msg }` )
						}
						else if( 'info' === json.type ){
							console.log( json.msg )
						}
						else {
							console.log( json.exec_time )

							document.querySelectorAll( '.fresh_views_js' ).forEach( function( el ){
								el.innerHTML = json.out
							} )
						}
					} )
					.catch( error => console.error( 'Postviews', error ) )

			},
			<?= $this->opt['hold_sec'] * 1000 ?>
		)
		</script>
		<?php
		$script = ob_get_clean();
		$script = preg_replace( '~</?script>~', '', $script );
		$script = preg_replace( '~^\t\t~m', '', $script );
		$script = trim( $script );

		/**
		 * Allow change or completely replace javascript code responsible for Kama Postviews ajax request.
		 *
		 * @param string $script Raw js code.
		 */
		$script = apply_filters( 'kama_postviews_script', $script );

		echo "\n".'<script async id="kama-postviews" src="data:text/javascript;base64,'. base64_encode( $script ) .'"></script>'."\n";

		/**
		 * Allows you to do something after the ajax script has been added to the page.
		 *
		 * @param object $data Current Postviews data.
		 */
		do_action( 'after_kama_postviews_show_js', $data );
	}

	/**
	 * Updates 'views_prev_month' meta-field of post or term.
	 *
	 * @param object $data Current request data.
	 */
	private function update_meta__views_prev_month( $data ){
		global $wpdb;

		if( ! in_array( $data->obj_type, [ 'post', 'term' ] ) ){
			return;
		}

		$prev_up_time = call_user_func( "get_{$data->obj_type}_meta", $data->obj_id, KPV_PREV_MONTH_UP_META_KEY, 1 );

		if(	! $prev_up_time || ( time() - DAY_IN_SECONDS > $prev_up_time ) ){

			// refresh time
			call_user_func( "update_{$data->obj_type}_meta", $data->obj_id, KPV_PREV_MONTH_UP_META_KEY, time() );

			$prev_prev_month = date( 'Y-m-01', strtotime('first day of -2 month') );
			$prev_month      = date( 'Y-m-01', strtotime('first day of -1 month') );

			$select_patt = $wpdb->prepare( "SELECT views FROM $wpdb->postviews WHERE obj_id = %d AND obj_type = %s",
				$data->obj_id, "$data->obj_type::$data->type_name"
			);
			$all_views_sql = str_replace( ' views ', ' SUM( views ) ', $select_patt );
			$select_ym_patt = "$select_patt AND yearmonth = %s";

			/**
			 * Counting for last month only starts if there is data for the month before last.
			 * Because the publication of material, as a rule, does not begin on the first day
			 * of the month, and in addition, it is not always visited immediately.
			 */
			$prev_prev_m_views = $wpdb->get_var( $wpdb->prepare( $select_ym_patt, $prev_prev_month ) );

			if( $prev_prev_m_views !== null ){

				$prev_m_views = $wpdb->get_var( $wpdb->prepare( $select_ym_patt, $prev_month ) );

				call_user_func( "update_{$data->obj_type}_meta", $data->obj_id, KPV_PREV_MONTH_META_KEY, $prev_m_views );
			}
			/**
			 * Check if there is any views of the post and there are no any prev month views,
			 * that means that post now not visited and we need to delete prev_month count meta-field
			 */
			elseif( $wpdb->get_var( $all_views_sql ) ){
				call_user_func( "delete_{$data->obj_type}_meta", $data->obj_id, KPV_PREV_MONTH_META_KEY );
			}
		}

	}

	/**
	 * @param object $data {
	 *     Data to be used for determine current page during counting the visit.
	 *
	 *     @type int    $obj_id    Current counting object ID. Ex: post id.
	 *                             Set 0 if the page have no ID ($obj_type must be unique in this case).
	 *     @type string $obj_type  Current counting object type. Ex: post, term, or custom type.
	 *     @type string $type_name Additional correction for type. Ex: post type, term taxonomy or empty string.
	 * }
	 */
	private function get_query_obj_data(){
		global $post;

		$allow = array_diff( kpviews()->get_available_types(), (array) $this->opt['blocktypes'] );
		$allow = array_flip( $allow );

		$data = (object) [
			'obj_id' => 0,
			'obj_type' => '',
			'type_name' => '',
		];

		$q_obj = get_queried_object();

		// front_page
		if( is_front_page() ){
			if( isset( $allow['front_page'] ) )
				$data->obj_type = 'front_page';
		}
		elseif( is_home() ){
			if( isset( $allow['home'] ) )
				$data->obj_type = 'home';
		}
		// search
		elseif( is_search() ){
			if( isset( $allow['search'] ) )
				$data->obj_type = 'search';
		}
		// 404
		elseif( is_404() ){
			if( isset( $allow['404'] ) )
				$data->obj_type = '404';
		}
		// author
		elseif( is_author() ){
			if( isset( $allow['author'] ) ){
				$data->obj_id = $q_obj->ID;
				$data->obj_type = 'author';
			}
		}
		// post_type_archive
		elseif( is_post_type_archive() ){
			if( isset( $allow['post_type_archive'] ) ){
				$data->obj_type = 'post_type_archive';
				$data->type_name = $q_obj->name;
			}
		}
		// year
		elseif( is_year() ){
			if( isset( $allow['year'] ) ){
				$data->obj_type = 'year_archive';
				$data->type_name = get_query_var('year');
			}
		}
		// month
		elseif( is_month() ){
			if( isset( $allow['month'] ) ){
				$data->obj_type = 'month_archive';
				$data->type_name = get_query_var('year') .'-'. get_query_var('monthnum');
			}
		}
		// day
		elseif( is_day() ){
			if( isset( $allow['day'] ) ){
				$data->obj_type = 'day_archive';
				$data->type_name = get_query_var('year') .'-'. get_query_var('monthnum') .'-'. get_query_var('day');
			}
		}
		// post
		elseif( isset( $q_obj->post_type ) && isset( $post->ID ) ){

			if( isset( $allow['post'] ) && isset( $allow[ $q_obj->post_type ] ) ){
				$data->obj_id    = (int) $post->ID;
				$data->obj_type  = 'post';
				$data->type_name = $q_obj->post_type;
			}
		}
		// term
		elseif( isset( $q_obj->term_id ) && function_exists( 'get_term_meta' ) ){
			if( isset( $allow['term'] ) && isset( $allow[ $q_obj->taxonomy ] ) ){
				$data->obj_id    = (int) $q_obj->term_id;
				$data->obj_type  = 'term';
				$data->type_name = $q_obj->taxonomy;
			}
		}

		return $data;
	}

	/**
	 * Gets all available types for count.
	 *
	 * @return array Array of allow types - special, post type names, tax names.
	 */
	public function get_available_types( $type = 'all' ){

		// 'attachment' в типах записей
		$common = [ 'front_page', 'home', 'search', '404', 'post_type_archive', 'author', 'year', 'month', 'day' ];
		$post_types = [ 'post' =>'post' ] + get_post_types( [ 'public' => true ], 'names' ); // post_types
		$taxonomies = [ 'term' =>'term' ] + get_taxonomies( [ 'public' => true ], 'names' ); // taxonomies

		if( $type === 'common' )     $allow = $common;
		if( $type === 'post_types' ) $allow = $post_types;
		if( $type === 'taxonomies' ) $allow = $taxonomies;
		if( $type === 'all' )        $allow = $common + $post_types + $taxonomies;

		return array_unique( $allow );
	}

	public static function _delete_views_data_by_hookname( $id ){

		$cur_action = current_action();

		if( $cur_action === 'deleted_post' ) $type = 'post';
		if( $cur_action === 'delete_term'  ) $type = 'term';
		if( $cur_action === 'deleted_user' ) $type = 'author';

		self::delete_views_data( $id, $type );
	}

	/**
	 * @param int    $id   Object id.
	 * @param string $type @see Kama_Postviews::get_available_types()
	 *
	 * @return bool
	 */
	public static function delete_views_data( $id, $type = 'post' ){
		global $wpdb;

		// post
		if( ( 'post' === $type ) && $obj = get_post( $id ) ){
			$obj_id   = $obj->ID;
			$obj_type = "post::$obj->post_type";
		}

		// term
		if( ( 'term' === $type ) && $obj = get_term( $id ) ){
			$obj_id   = $obj->term_id;
			$obj_type = "term::$obj->taxonomy";
		}
		// author and others types
		if( empty( $obj_id ) ){
			$obj_id = (int) $id;
			$obj_type = $type;
		}

		$kpid = $wpdb->get_col( $wpdb->prepare(
			"SELECT kpid FROM $wpdb->postviews WHERE obj_id = %d AND obj_type = %s",
			$obj_id, $obj_type
		) );

		$affected_rows = 0;

		if( $kpid ){
			$kpid_IN = implode( ',', $kpid );
			$affected_rows += $wpdb->query( "DELETE FROM $wpdb->postviews WHERE kpid IN ($kpid_IN)" );
			$affected_rows += $wpdb->query( "DELETE FROM $wpdb->postviews_meta WHERE kpid IN ($kpid_IN)" );
		}

		return (bool) $affected_rows;
	}

}


