<?php

namespace Kama_Postviews\Upgrade;

function version_3_2_7_2(){
	global $wpdb;

	$wpdb->query( "ALTER TABLE $wpdb->postviews ADD KEY obj_id_type (obj_id,obj_type)" );
	$wpdb->query( "ALTER TABLE $wpdb->postviews ADD KEY obj_type_yearmonth (obj_type,yearmonth)" );

	$wpdb->query( "ALTER TABLE $wpdb->postviews DROP KEY obj_id_type_month" );

	// удалим строки с пустым obj_type - был баг в ajax-request.php
	$wpdb->query( "DELETE FROM $wpdb->postviews_meta WHERE kpid IN ( SELECT kpid FROM $wpdb->postviews WHERE obj_type = '' )" );
	$wpdb->query( "DELETE FROM $wpdb->postviews WHERE obj_type = ''" );

	$opts = kpviews()->opt;

	if( 'добавим author в исключение и переделаем опцию blocktypes в массив' ){

		// тут работает функция очистки из register_setting( 'option_group', Kama_Postviews::OPT_NAME, array( $this, 'option_sanitize_cb') );
		if( is_string( $opts['blocktypes'] ) ){
			$opts['blocktypes'] = array_filter( array_map( 'trim', explode( ',', $opts['blocktypes'] ) ) );
		}
		if( empty( $opts['blocktypes'] ) ){
			$opts['blocktypes'] = kpviews()->default_options()['blocktypes'];
		}
		if( ! in_array( 'author', $opts['blocktypes'], true ) ){
			$opts['blocktypes'][] = 'author';
			$opts['blocktypes'][] = 'post_format';
		}
	}

	return update_option( kpviews()->OPT_NAME, $opts );
}

function version_3_2_4(){

	$opts = kpviews()->opt;

	if( $opts['who_count'] === 'not_administrators' ){
		$opts['who_count'] = 'not_admins';

		return update_option( kpviews()->OPT_NAME, $opts );
	}
}

function version_3_1_5(){
	global $wpdb;

	// Обновим type в таблице postviews
	// post > post::post или post::attachment
	$wpdb->query(
		"UPDATE $wpdb->postviews SET obj_type = CONCAT(obj_type, CONCAT('::', (SELECT post_type FROM $wpdb->posts WHERE ID = obj_id) ) ) WHERE obj_type = 'post'"
	);

	// term > term::post_tag
	$wpdb->query(
		"UPDATE $wpdb->postviews SET obj_type = CONCAT(obj_type, CONCAT('::', (SELECT taxonomy FROM $wpdb->term_taxonomy WHERE term_id = obj_id) ) ) WHERE obj_type = 'term'"
	);

	// product---post_type_archive > post_type_archive::product
	$results = $wpdb->get_results(
		"SELECT kpid, obj_type FROM $wpdb->postviews WHERE obj_type LIKE '%---%'"
	);

	foreach( $results as $res ){
		list( $one, $two ) = explode( '---', $res->obj_type );
		$wpdb->query( "UPDATE $wpdb->postviews SET obj_type = '$two::$one' WHERE kpid = $res->kpid" );
	}

	return true;
}

function version_2_0_0( $cols_kpm ){
	global $wpdb;

	$fields_kpm = array_keys( $cols_kpm );

	$done = null;

	if( ! in_array( 'kpmid', $fields_kpm, 1 ) ){
		$done += $wpdb->query(
			"ALTER TABLE $wpdb->postviews_meta ADD COLUMN `kpmid` BIGINT(20) unsigned NOT NULL auto_increment FIRST, ADD PRIMARY KEY (kpmid)"
		);
	}

	if( in_array( 'meta_type', $fields_kpm, 1 ) ){
		$done += $wpdb->query(
			"ALTER TABLE $wpdb->postviews_meta CHANGE COLUMN `meta_type` `meta_key` VARCHAR(150) NOT NULL DEFAULT ''"
		);
	}

	return $done;
}







