<?php

namespace Kama_Postviews\Upgrade;

/**
 * Upgrader class
 *
 * @version 1.0
 */
class Kama_Postviews_Upgrade {

	/**
	 * @param null $force
	 *
	 * @return array Upgrade data.
	 */
	public static function init( $force = null ){

		$ver_opt_name = 'kama_postviews_ver';

		$db_ver = get_option( $ver_opt_name );

		if( $force === null ){
			$force = isset( $_REQUEST['force_kap_up'] );
		}

		// already updated OR installed
		// do anyway if force
		if( ! $force && KPV_VER === $db_ver ){
			return [];
		}

		if( ! $db_ver ){
			self::activation();
			update_option( $ver_opt_name, KPV_VER );
			return [];
		}

		$res = [];

		$res['upgrade'] = self::upgrade( $db_ver );

		$res['activation']= self::activation();

		update_option( $ver_opt_name, KPV_VER );

		return $res;
	}

	/**
	 * All operation to do during activation.
	 *
	 * @return array Activation result.
	 */
	public static function activation(){

		// create/update DB tables
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$dbDelta_tables = self::dbDelta_tables( self::tables_schemas() );

		$res = [];

		foreach( $dbDelta_tables as $table_name => $table_query ){

			$res['dbDelta'][ $table_name ] = dbDelta( $table_query );

			// почистим значения которые ничего не означают
			foreach( $res['dbDelta'][ $table_name ] as & $val ){
				if( preg_match( '/ to\s*$/', $val ) ){
					$val = '';
				}
			}
		}

		return $res;
	}

	/**
	 * Code Need to be executed before self::activation() runs.
	 *
	 * @param string $db_ver  The version from which we update (the previous version,
	 *                        the current version in the database before the update).
	 * @return array Upgrade result.
	 */
	private static function upgrade( $db_ver ){
		global $wpdb;

		require_once __DIR__ . '/upgrade-functions.php';

		$res = [];

		//$cols_kp = $wpdb->get_results( "SHOW COLUMNS FROM $wpdb->postviews", OBJECT_K );
		//$keys_kp = $wpdb->get_results( "SHOW INDEX FROM $wpdb->postviews" );
		$cols_kpm = $wpdb->get_results( "SHOW COLUMNS FROM $wpdb->postviews_meta", OBJECT_K );
		//$keys_kpm = $wpdb->get_results( "SHOW INDEX FROM $wpdb->postviews_meta" );

		if( version_compare( $db_ver, $ver = '2.0.0', '<=' ) )   $res[ $ver ] = Kama_Postviews\Upgrade\version_2_0_0( $cols_kpm );
		if( version_compare( $db_ver, $ver = '3.1.5', '<=' ) )   $res[ $ver ] = Kama_Postviews\Upgrade\version_3_1_5();
		if( version_compare( $db_ver, $ver = '3.2.4', '<=' ) )   $res[ $ver ] = Kama_Postviews\Upgrade\version_3_2_4();
		if( version_compare( $db_ver, $ver = '3.2.7.2', '<=' ) ) $res[ $ver ] = Kama_Postviews\Upgrade\version_3_2_7_2();

		return array_filter( $res );
	}

	/**
	 * Prepare for dbDelta
	 *
	 * @param array $tables Tables schemas. Array with pairs `[ table_name => sql_schema ]`.
	 *
	 * @return array
	 */
	private static function dbDelta_tables( $tables ){
		global $wpdb;

		$collate_charset_engine = $wpdb->get_charset_collate() . ' ENGINE InnoDB';

		// prepare for dbDelta
		foreach( $tables as & $query ){

			$query = trim( $query );
			$query = preg_replace( '/^\s+|\s+$/m', '', $query ); // delete \s\s...
			$query = preg_replace( '/^--.+$/m',    '', $query ); // delete sql comment
			$query = preg_replace( "/\r/",         '', $query ); // delete caret
			$query = preg_replace( "/\n\n+/",    "\n", $query ); // delete double line break
			$query = strtr( $query, [
				' TINYINT('   => ' tinyint(',
				' INT('       => ' int(',
				' VARCHAR('   => ' varchar(',
				' CHAR('      => ' char(',
				' YEAR('      => ' year(',
				' DOUBLE('    => ' double(',
				' TEXT '      => ' text ',
				' TIMESTAMP ' => ' timestamp ',
				' DATETIME '  => ' datetime ',
				' UNSIGNED '  => ' unsigned ',
			] );

			$query = rtrim( $query, ';' ) . " $collate_charset_engine;";
		}
		unset( $query );

		return array_filter( $tables );
	}

	private static function tables_schemas(){
		global $wpdb;

		$schemas = [];

		$schemas[ $wpdb->postviews ] = "
		CREATE TABLE $wpdb->postviews (
			kpid       BIGINT(20)    unsigned NOT NULL auto_increment,
			obj_id     BIGINT(20)    unsigned NOT NULL default 0,
			obj_type   VARCHAR(150)           NOT NULL default '',
			yearmonth  DATE                   NOT NULL default '1970-01-01',
			views      BIGINT(20)    unsigned NOT NULL default 0,
			day_1      BIGINT(20)    unsigned NOT NULL default 0,
			day_2      BIGINT(20)    unsigned NOT NULL default 0,
			day_3      BIGINT(20)    unsigned NOT NULL default 0,
			day_4      BIGINT(20)    unsigned NOT NULL default 0,
			day_5      BIGINT(20)    unsigned NOT NULL default 0,
			day_6      BIGINT(20)    unsigned NOT NULL default 0,
			day_7      BIGINT(20)    unsigned NOT NULL default 0,
			day_8      BIGINT(20)    unsigned NOT NULL default 0,
			day_9      BIGINT(20)    unsigned NOT NULL default 0,
			day_10     BIGINT(20)    unsigned NOT NULL default 0,
			day_11     BIGINT(20)    unsigned NOT NULL default 0,
			day_12     BIGINT(20)    unsigned NOT NULL default 0,
			day_13     BIGINT(20)    unsigned NOT NULL default 0,
			day_14     BIGINT(20)    unsigned NOT NULL default 0,
			day_15     BIGINT(20)    unsigned NOT NULL default 0,
			day_16     BIGINT(20)    unsigned NOT NULL default 0,
			day_17     BIGINT(20)    unsigned NOT NULL default 0,
			day_18     BIGINT(20)    unsigned NOT NULL default 0,
			day_19     BIGINT(20)    unsigned NOT NULL default 0,
			day_20     BIGINT(20)    unsigned NOT NULL default 0,
			day_21     BIGINT(20)    unsigned NOT NULL default 0,
			day_22     BIGINT(20)    unsigned NOT NULL default 0,
			day_23     BIGINT(20)    unsigned NOT NULL default 0,
			day_24     BIGINT(20)    unsigned NOT NULL default 0,
			day_25     BIGINT(20)    unsigned NOT NULL default 0,
			day_26     BIGINT(20)    unsigned NOT NULL default 0,
			day_27     BIGINT(20)    unsigned NOT NULL default 0,
			day_28     BIGINT(20)    unsigned NOT NULL default 0,
			day_29     BIGINT(20)    unsigned NOT NULL default 0,
			day_30     BIGINT(20)    unsigned NOT NULL default 0,
			day_31     BIGINT(20)    unsigned NOT NULL default 0,
			
			PRIMARY KEY  (kpid),
			KEY obj_id_type (obj_id,obj_type),
			KEY obj_type_yearmonth (obj_type,yearmonth)
	
		)";

		$schemas[ $wpdb->postviews_meta ] = "
		CREATE TABLE $wpdb->postviews_meta (
			kpmid    BIGINT(20)    unsigned NOT NULL auto_increment,
			kpid     BIGINT(20)    unsigned NOT NULL default 0,
			meta_key VARCHAR(150)           NOT NULL default '',
			views    BIGINT(20)    unsigned NOT NULL default 0,
			day_1    BIGINT(20)    unsigned NOT NULL default 0,
			day_2    BIGINT(20)    unsigned NOT NULL default 0,
			day_3    BIGINT(20)    unsigned NOT NULL default 0,
			day_4    BIGINT(20)    unsigned NOT NULL default 0,
			day_5    BIGINT(20)    unsigned NOT NULL default 0,
			day_6    BIGINT(20)    unsigned NOT NULL default 0,
			day_7    BIGINT(20)    unsigned NOT NULL default 0,
			day_8    BIGINT(20)    unsigned NOT NULL default 0,
			day_9    BIGINT(20)    unsigned NOT NULL default 0,
			day_10   BIGINT(20)    unsigned NOT NULL default 0,
			day_11   BIGINT(20)    unsigned NOT NULL default 0,
			day_12   BIGINT(20)    unsigned NOT NULL default 0,
			day_13   BIGINT(20)    unsigned NOT NULL default 0,
			day_14   BIGINT(20)    unsigned NOT NULL default 0,
			day_15   BIGINT(20)    unsigned NOT NULL default 0,
			day_16   BIGINT(20)    unsigned NOT NULL default 0,
			day_17   BIGINT(20)    unsigned NOT NULL default 0,
			day_18   BIGINT(20)    unsigned NOT NULL default 0,
			day_19   BIGINT(20)    unsigned NOT NULL default 0,
			day_20   BIGINT(20)    unsigned NOT NULL default 0,
			day_21   BIGINT(20)    unsigned NOT NULL default 0,
			day_22   BIGINT(20)    unsigned NOT NULL default 0,
			day_23   BIGINT(20)    unsigned NOT NULL default 0,
			day_24   BIGINT(20)    unsigned NOT NULL default 0,
			day_25   BIGINT(20)    unsigned NOT NULL default 0,
			day_26   BIGINT(20)    unsigned NOT NULL default 0,
			day_27   BIGINT(20)    unsigned NOT NULL default 0,
			day_28   BIGINT(20)    unsigned NOT NULL default 0,
			day_29   BIGINT(20)    unsigned NOT NULL default 0,
			day_30   BIGINT(20)    unsigned NOT NULL default 0,
			day_31   BIGINT(20)    unsigned NOT NULL default 0,
			
			PRIMARY KEY  (kpmid),
			KEY kpid (kpid),
			KEY meta_key (meta_key)
		)";

		$schemas[ $wpdb->postviews_temp_log ] = "
		CREATE TABLE $wpdb->postviews_temp_log (
			log_id      BIGINT(20)    unsigned NOT NULL auto_increment,
			user_id     BIGINT(20)             NOT NULL default 0,
			obj_id_type VARCHAR(150)           NOT NULL default '',
			IP          VARCHAR(150)           NOT NULL default '',
			log_time    DATETIME               NOT NULL default '0000-00-00 00:00:00',
			user_agent  TEXT                   NOT NULL default '',
			
			PRIMARY KEY  (log_id),
			KEY obj_user_id_IP (obj_id_type,user_id,IP)
		)";

		return $schemas;
	}

}
