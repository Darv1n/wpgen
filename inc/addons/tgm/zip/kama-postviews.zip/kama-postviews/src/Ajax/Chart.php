<?php

namespace Kama_Postviews\Ajax;

class Chart {

	public static function draw_single_object_chart(){

		$type = preg_replace( '/^(\w+).*/', '$1', $_POST['db_obj_type'] );

		if( 'term' === $type ){
			$title = get_term( $_POST['obj_id'] )->name;
		}
		elseif( 'post' === $type ){
			$title = get_post( $_POST['obj_id'] )->post_title;
		}

		echo '<h1 class="chart-title">'. esc_html( $title ) .'</h1>';

		kpv_draw_single_object_chart( [
			'month_limit' => (int) $_POST['month_limit'],
			'obj_id'      => (int) $_POST['obj_id'],
			'obj_type'    => sanitize_text_field( $_POST['db_obj_type'] ),
		] );

		exit;
	}

	public static function re_draw_single_object_chart(){

		$data = kpv_get_object_viewsdata( [
			'month_limit' => (int) $_POST['month_limit'],
			'obj_id'      => (int) $_POST['obj_id'],
			'obj_type'    => sanitize_text_field( $_POST['db_obj_type'] ),
		] );

		if( $data && ! empty( $data['viewsdata'] ) ){
			echo kpv_draw_single_object_chart_js( $data['viewsdata'], $data['meta_keys'], 'redraw' );
		}

		exit;
	}

}
