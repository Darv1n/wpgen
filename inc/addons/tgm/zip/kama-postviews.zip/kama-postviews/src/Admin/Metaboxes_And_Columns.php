<?php

namespace Kama_Postviews\Admin;

/**
 * Additional sortable columns of views for posts in the admin panel.
 * Metaboxes in the admin panel.
 *
 * Inits on 'admin_init' hook.
 */
final class Metaboxes_And_Columns {

	/**
	 * Runs on 'admin_init' hook.
	 */
	public static function init(){

		$blocktypes = kpviews()->opt['blocktypes'];

		// some taxonomies are available (not blocked)
		if( ! in_array( 'term', $blocktypes, true ) ){
			$allowed_taxonomies = array_diff( kpviews()->get_available_types( 'taxonomies' ), $blocktypes );

			Metaboxes_Taxonomies::init( $allowed_taxonomies );
			Columns_Taxonomies::init( $allowed_taxonomies );
		}

		// some post_types are available (not blocked)
		if( ! in_array( 'post', $blocktypes, true ) ){
			$allowed_post_types = array_diff( kpviews()->get_available_types('post_types'), $blocktypes );

			Metaboxes_Posts::init( $allowed_post_types );
			Columns_Posts::init( $allowed_post_types );
		}

		add_action( 'admin_head', [ __CLASS__, 'tax_post_columns_css' ] );
	}

	static function tax_post_columns_css(){

		if( in_array( get_current_screen()->base, [ 'edit-tags', 'edit' ] ) ){
			echo '<style> .column-views, .column-views_prev_month{ width:6em; white-space:nowrap; } </style>';
		}

	}

}



