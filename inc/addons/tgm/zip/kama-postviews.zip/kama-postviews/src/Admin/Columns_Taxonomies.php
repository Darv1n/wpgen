<?php

namespace Kama_Postviews\Admin;

class Columns_Taxonomies extends Columns_Common {

	static function init( $taxonomies ){

		foreach( $taxonomies as $taxname ){

			add_filter( "manage_edit-{$taxname}_columns",  [ __CLASS__, 'add_tax_column' ] );
			add_filter( "manage_{$taxname}_custom_column", [ __CLASS__, 'fill_tax_column' ], 10, 3 );

			add_filter( "manage_edit-{$taxname}_sortable_columns", [ __CLASS__, 'add_sortable_column' ] );
		}

		// Изменим запрос - вариант 2
		add_filter( 'terms_clauses', [ __CLASS__, 'tax_sort_request' ], 10, 3 );
	}

	static function add_tax_column( $columns ){
		return self::_add_column( 'tax', $columns );
	}

	static function fill_tax_column( $out, $colname, $term_id ){

		if( in_array( $colname, [ 'views', 'views_prev_month' ], true ) ){
			return self::_fill_column( 'term', $term_id, $colname );
		}

		return $out;
	}

	static function tax_sort_request( $pieces, $taxonomies, $args ){
		global $wpdb;

		// убедимся, что мы там где нужно
		if(
			! is_admin()
			|| empty( $_GET['orderby'] )
			|| ! in_array( $_GET['orderby'], [ 'views', 'views_prev_month' ] )
		){
			return $pieces;
		}

		// убедимся что функция get_terms вызывается именно из класса с таблицей
		$backtrace = debug_backtrace( false );
		$backtrace = array_pop( $backtrace );
		if( empty( $backtrace['class'] ) ){
			return $pieces;
		}

		// дополним запрос
		if(
			( $backtrace['class'] === 'WP_List_Table')  // для таблицы терминов
			||
			( $backtrace['class'] === 'WP_Terms_List_Table' ) // для подсчета количества найденных
		){
			$orderby = $_GET['orderby'];
			$map = [
				'views' => KPV_META_KEY,
				'views_prev_month' => KPV_PREV_MONTH_META_KEY,
			];
			if( isset( $map[ $orderby ] ) ){
				$orderby = $map[ $orderby ];
			}
			$pieces['join']  .= " LEFT JOIN $wpdb->termmeta AS tmeta ON t.term_id = tmeta.term_id ";
			$pieces['where'] .= " AND tmeta.meta_key = '". esc_sql( $orderby ) ."' ";
		}

		// только для таблицы терминов
		if( $backtrace['class'] === 'WP_List_Table' ){
			$pieces['orderby']  = " ORDER BY tmeta.meta_value+0 ";
		}

		return $pieces;
	}
}
