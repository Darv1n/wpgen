<?php

namespace Kama_Postviews\Admin;


abstract class Metaboxes_Common {

	protected static function chart_html( $obj ){

		kpv_single_object_chart_html( $obj );

		add_action( 'admin_print_footer_scripts', [ __CLASS__, 'chart_object_js' ], 99 );
	}

	public static function chart_object_js(){
		global $post, $tag;

		$cs = get_current_screen();
		if( ! $cs ){
			return;
		}

		$obj_id = 0;
		$db_obj_type = '';

		if( 'term' === $cs->base ){
			$obj_id = (int) $tag->term_id;
			$db_obj_type = "term::$tag->taxonomy";
		}
		elseif( 'post' === $cs->base ){
			$obj_id = (int) $post->ID;
			$db_obj_type = "post::$post->post_type";
		}

		$data = kpv_get_object_viewsdata( [
			'month_limit' => 6,
			'obj_id'      => $obj_id,
			'obj_type'    => $db_obj_type,
		] );

		if( $data && ! empty( $data['viewsdata'] ) ){
			kpv_draw_single_object_chart_js( $data['viewsdata'], $data['meta_keys'] );
		}
	}

	protected static function _views_inputs( $obj ){

		$id = isset( $obj->term_id ) ? $obj->term_id : $obj->ID;
		$type = isset( $obj->term_id ) ? 'term' : 'post';
		$vdata = kpv_get_object_views_data( $id, $type );

		ob_start();
		?>
		<div style="text-align:center">
			<?= __( 'All views', 'kap' ) ?> →
			<input disabled type="number" min="0" name="kpvmeta[views]" value="<?= (int) $vdata['all'] ?>" style="max-width:100px;">
			::
			<input disabled type="number" min="0" name="kpvmeta[views_prev_month]" value="<?= (int) $vdata['month'] ?>" style="max-width:100px;">
			← <?= __( 'Previous month views', 'kap' ) ?>
		</div>
		<?php

		return ob_get_clean();
	}

}