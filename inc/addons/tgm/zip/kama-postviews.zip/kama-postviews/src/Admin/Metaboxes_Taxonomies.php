<?php

namespace Kama_Postviews\Admin;


class Metaboxes_Taxonomies extends Metaboxes_Common {

	public static function init( $taxonomies ){

		foreach( $taxonomies as $taxname ){
			add_action( "{$taxname}_edit_form", [ __CLASS__, 'add_term_metabox' ], 99 );
		}

		add_action( 'edit_term', [ __CLASS__, 'save_term_metabox' ] );
	}

	public static function add_term_metabox( $term ){
		?>
		<h4><?php _e( 'Views', 'kap' ) ?></h4>
		<div class="kama-postviews-term-metabox">
			<?php
			echo self::chart_html( $term );
			echo self::_views_inputs( $term );
			?>
		</div>
		<?php
	}

	static function save_term_metabox( $term_id ){

		if( empty( $_POST['kpvmeta'] ) ){
			return;
		}

		update_term_meta( $term_id, KPV_META_KEY, (int) $_POST['kpvmeta']['views'] );
		update_term_meta( $term_id, KPV_PREV_MONTH_META_KEY, (int) $_POST['kpvmeta']['views_prev_month'] );
	}
}