<?php

namespace Kama_Postviews\Admin;


abstract class Columns_Common {

	static function add_sortable_column( $sortable_columns ){

		$sortable_columns['views_prev_month'] = [ 'views_prev_month', 'desc' ];
		$sortable_columns['views']            = [ 'views',            'desc' ];

		return $sortable_columns;
	}

	static function _add_column( $type, $columns ){

		( $type === 'post' ) && $after_col = 'title';
		( $type === 'tax' )  && $after_col = 'description';

		$_cols = [];
		foreach( $columns as $key => $col ){
			$_cols[ $key ] = $col;

			if( $key === $after_col ){
				$patt = '<span title="%s">&#128065; %s</span>'; // &#128065; → 👁

				$_cols['views_prev_month'] = sprintf( $patt, __( 'Views prev month', 'kap' ), _x( 'mon', 'month', 'kap' ) );
				$_cols['views'] = sprintf( $patt, __( 'All views', 'kap' ), _x( 'all', 'all months', 'kap' ) );
			}
		}
		$columns = $_cols;

		return $columns;
	}

	static function _fill_column( $type, $obj_id, $colname ){

		$meta_key = 'views' === $colname ? KPV_META_KEY : KPV_PREV_MONTH_META_KEY;
		$type_name = 'post' === $type ? get_post( $obj_id )->post_type : get_term( $obj_id )->taxonomy;

		// $type: post, term
		$views = call_user_func( "get_{$type}_meta", $obj_id, $meta_key, 1 );

		if( ! $views ){
			return '' === $views ? '—' : '0';
		}

		if( 'views' === $colname ){
			return sprintf( '<a href="#" onclick="window.kpvChartPopup( %d, \'%s\' ); return false;">%s</a>',
				$obj_id, kpv_generate_db_obj_type( $type, $type_name ), number_format_i18n( $views )
			);
		}

		return number_format_i18n( $views );
	}
}