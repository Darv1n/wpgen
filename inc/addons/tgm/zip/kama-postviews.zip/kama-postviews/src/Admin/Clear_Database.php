<?php

namespace Kama_Postviews\Admin;

use WP_Error;

class Clear_Database {

	public static $less_then_per_month = 4;
	public static $month_earlier = 5;

	public static function base_sql(){
		global $wpdb;

		$less_then_per_month = self::$less_then_per_month;
		$month_earlier       = self::$month_earlier;

		$yearmonth = date( 'Y-m-01', strtotime( "first day of -$month_earlier month" ) );
		$sql_main = "SELECT kpid FROM $wpdb->postviews WHERE views <= $less_then_per_month AND yearmonth < '$yearmonth'";
		$sql_meta = "SELECT count(*) FROM $wpdb->postviews_meta WHERE kpid IN ( $sql_main )";

		return [
			'main' => $sql_main,
			'meta' => $sql_meta,
			'main_delete' => str_replace( 'SELECT kpid', 'DELETE', $sql_main ),
			'meta_delete' => str_replace( 'SELECT count(*)', 'DELETE', $sql_meta ),
			'main_count' => str_replace( 'kpid', 'count(*)', $sql_main ),
			'meta_count' => $sql_meta,
		];
	}

	/**
	 * @return int|WP_Error Deleted rows.
	 */
	public static function do_clearing(){
		global $wpdb;

		$sql = self::base_sql();

		$deleted_rows = 0;

		$res = $wpdb->query( $sql['main_delete'] );

		if( false === $res ){
			return new WP_Error( 'err', 'ERROR: main_delete sql error' );
		}
		$deleted_rows += $res;

		$res = $wpdb->query( $sql['meta_delete'] );

		if( false === $res ){
			return new WP_Error( 'err', 'ERROR: meta_delete sql error' );
		}
		$deleted_rows += $res;

		return $deleted_rows;
	}

	public static function clear_option_html(){
		global $wpdb;

		$sql = self::base_sql();

		$rows_to_del = $wpdb->get_var( $sql['main_count'] );
		$rows_to_del += $wpdb->get_var( $sql['meta_count'] );

		if( $rows_to_del > 100 ){
			$echo = '
				<a class="button" href="' . esc_url( add_query_arg( 'delete_DB_old_useless_data', '1' ) ) . '" 
					onclick="return confirm(\'' . __( 'Are you sure?', 'kap' ) . '\');"
				>
					' . __( 'Delete useless data', 'kap' ) . ' (' . $rows_to_del . ' ' . __( 'rows to delete', 'kap' ) . ')
				</a>
				<p class="description">' . sprintf( __( 'Delete old data (%d months and later) from database with less when %d views per month. These data seem to be useless and only take up space in the database.', 'kap' ), self::$month_earlier, self::$less_then_per_month ) . '</p>
				';
		}
		else {
			$echo = __( 'Nothing to clean yet...', 'kap' );
		}

		return $echo;

	}

}
