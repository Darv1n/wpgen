<?php

namespace Kama_Postviews\Admin;


class Metaboxes_Posts extends Metaboxes_Common {

	public static function init( $post_types ){

		foreach( $post_types as $ptype ){

			add_action( "add_meta_boxes_{$ptype}", [ __CLASS__, 'add_post_metabox' ], 10, 2 );
		}

		add_action( 'save_post', [ __CLASS__, 'save_post_metabox' ], 0, 2 );
	}

	static function add_post_metabox( $post ){

		if( $post->post_status !== 'publish' ){
			return;
		}

		add_meta_box( 'kap_post_metabox', __('Views','kap'), [ __CLASS__, '_add_metabox_html' ], $post->post_type, 'normal', 'high'  );
	}

	static function _add_metabox_html( $post ){

		echo self::chart_html( $post );

		?>
		<div style="margin:2em 0 1em; text-align:center;">
			<?= self::_views_inputs( $post ) ?>
		</div>
		<?php
	}

	static function save_post_metabox( $post_id, $post ){

		if(
			empty( $_POST['kpvmeta'] )                                                               || // нет данных
			( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE  )                                         || // выходим, если это автосохр.
			! wp_verify_nonce( $_POST['_wpnonce'], "update-post_{$post_id}" )                        || // nonce проверка
			! current_user_can( get_post_type_object( $post->post_type )->cap->edit_post, $post_id )    // нет права редакт. запись
		){
			return;
		}

		$metas = $_POST['kpvmeta'];

		update_post_meta( $post_id, KPV_META_KEY,            (int) $metas['views']            );
		update_post_meta( $post_id, KPV_PREV_MONTH_META_KEY, (int) $metas['views_prev_month'] );
	}

}