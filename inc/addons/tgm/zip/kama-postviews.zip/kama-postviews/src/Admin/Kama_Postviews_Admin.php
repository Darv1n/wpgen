<?php

namespace Kama_Postviews\Admin;

class Kama_Postviews_Admin {

	use Options;

	public function __construct(){

		add_action( 'admin_menu', [ $this, 'add_options_page' ] );
		add_action( 'admin_init', [ $this, 'admin_init' ] );

		add_action( 'admin_head', 'kpv_chart_overlay_css' );
		add_action( 'admin_footer', 'kpv_chart_overlay_html' );

		add_filter( 'plugin_action_links_'. KPV_BASE, [ $this, 'settings_link' ] );

		add_action( 'wp_ajax_'.'kpv_delete_meta_key_data', [ \Kama_Postviews\Admin\Ajax::class, 'delete_meta_key_data' ] );
	}

	public function admin_init(){

		$this->register_setting();

		require_once __DIR__ . '/Metaboxes_And_Columns.php';

		Metaboxes_And_Columns::init();
	}

	/**
	 * Settings page link in plugins table.
	 *
	 * @param $links
	 *
	 * @return mixed
	 */
	public function settings_link( $links ){
		array_unshift( $links, '<a href="'. admin_url('options-general.php?page=kama_postviews') .'">'. __('Settings','kap') .'</a>' );
		return $links;
	}

}
