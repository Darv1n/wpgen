<?php

namespace Kama_Postviews\Admin;

// TODO move to separate abstraction

trait Options {

	public function add_options_page(){

		$hook_name = add_submenu_page( 'options-general.php', 'Kama Postviews', 'Kama Postviews', 'manage_options', 'kama_postviews', [ $this, '_options_page_output' ] );

		add_action( "load-$hook_name", [ $this, '_options_page_load' ] );
	}

	public function _options_page_load(){

		wp_enqueue_script( 'kpv_admin', KPV_URL .'js/admin.js', [ 'jquery' ], KPV_VER, true );

		self::handle_delete_DB_old_useless_data();
	}

	private static function handle_delete_DB_old_useless_data(){

		if( ! isset( $_GET['delete_DB_old_useless_data'] ) || ! current_user_can( 'manage_options' ) ){
			return;
		}

		$res = Clear_Database::do_clearing();

		if( is_wp_error( $res ) ){
			wp_die( $res->get_error_message() ); // TODO show admin notice
		}

		$redirect_url = remove_query_arg( 'delete_DB_old_useless_data' );
		wp_safe_redirect( $redirect_url );
		exit;
	}

	public function _options_page_output(){
		?>
		<div class="wrap">
			<h2>Kama Postviews</h2>

			<form action="options.php" method="POST">
				<?php
				settings_fields('option_group');  // скрытые защитные поля
				do_settings_sections('kap_page'); // секции с настройками (опциями). У нас она всего одна 'section_id'
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	# settings are saves as array
	private function register_setting(){

		// _option_sanitize_cb будет срабатывают для всех вызовов update_option
		register_setting( 'option_group', kpviews()->OPT_NAME, [ $this, '_option_sanitize_cb' ] );

		$section = 'kap_section_1';
		add_settings_section( $section, '', '', 'kap_page' );

		// параметры: $id, $title, $callback, $page, $section, $args
		$id = 'who_count';
		add_settings_field( $id, __( 'Whose Visit Count?', 'kap' ),
			[ $this, '_fill_field', ], 'kap_page', $section, [ 'id' => $id, 'desc' => '' ]
		);

		$id = 'hold_sec';
		add_settings_field( $id, __( 'Delay in seconds', 'kap' ),
			[ $this, '_fill_field' ], 'kap_page', $section, [
				'id'   => $id,
				'desc' => __( 'How many seconds to wait before start count the visit?', 'kap' ) .' '. __( 'Within this time, the user can leave the site and the visit will not be counted.', 'kap' ),
			]
		);

		$id = 'hold_sec_between_counts';
		add_settings_field( $id, __( 'Time Between Counts', 'kap' ),
			[ $this, '_fill_field' ], 'kap_page', $section, [
				'id'   => $id,
				'desc' => __( 'Specify the minimum number of seconds to count the next visit of an individual user.', 'kap' ),
			]
		);

		$id = 'blocktypes';
		add_settings_field( $id, __( 'Disable Views Counting', 'kap' ),
			[ $this, '_fill_field' ], 'kap_page', $section, [
				'id'   => $id,
				'desc' => __( 'EXCLUDE type of pages from counting visits:', 'kap' ),
			] );

		$id = 'show_prev_m_views';
		add_settings_field( $id, __( 'Previous Month Views', 'kap' ), [ $this, '_fill_field' ], 'kap_page', $section, [
			'id'   => $id,
			'desc' => __( 'Whether to show prev month views next to all views?', 'kap' ),
		] );

		$id = 'chart_colors_theme';
		add_settings_field( $id, __( 'Chart Color Theme', 'kap' ), [ $this, '_fill_field' ], 'kap_page', $section, [
			'id' => $id,
		] );

		$id = 'clear_db_tables';
		add_settings_field( $id, __( 'Clearing the Database', 'kap' ), [ $this, '_fill_field' ], 'kap_page', $section, [
			'id' => $id,
		] );

		$id = 'allowed_meta_keys';
		add_settings_field( $id, __( 'Allowed Meta Keys', 'kap' ), [ $this, '_fill_field' ], 'kap_page', $section, [
			'id' => $id,
			'desc' => __( 'Uncheck the checkboxes to not write the specified data to the database.', 'kap' ),
		] );

		$id = 'licence_key';
		add_settings_field( $id, __( 'License Key', 'kap' ), [ $this, '_fill_field' ], 'kap_page', $section, [
			'id' => $id,
		] );

	}

	public function _fill_field( $args ){
		global $wpdb;

		$id = $args['id'];
		$desc = ! empty( $args['desc'] ) ? '<p class="description">' . $args['desc'] . '</p>' : '';
		$name = kpviews()->OPT_NAME . "[$id]";
		$val = isset( kpviews()->opt[ $id ] ) ? kpviews()->opt[ $id ] : null; // for license_key

		if( 'who_count' === $id ){
			$options = [];

			foreach(
				[
					'all'                    => __('All','kap'),
					'not_logged_users'       => __('Only not logged users','kap'),
					'logged_users'           => __('Only logged users','kap'),
					'not_admins'             => __('All, except admins','kap'),
					'not_admins_and_authors' => __('All, except admins and author of post','kap'),
				]
				as $opt_key => $opt_label
			){
				$options[] = sprintf( '<option value="%s" %s>%s</option>', $opt_key, selected( $val, $opt_key, 0 ), $opt_label );
			}

			echo '<select name="'. $name .'">'. implode("\n", $options) .'</select>';
			echo $desc;
		}

		elseif( 'chart_colors_theme' === $id ){
			$options = [];

			foreach(
				[
					'tomorrow_soft' => 'Tomorrow Soft',
					'tomorrow_hard' => 'Tomorrow Hard',
				]
				as $opt_key => $opt_label
			){
				$options[] = sprintf( '<option value="%s" %s>%s</option>', $opt_key, selected( $val, $opt_key, 0 ), $opt_label );
			}

			echo '<select name="'. $name .'">'. implode("\n", $options) .'</select>';
			echo $desc;
		}

		elseif( 'allowed_meta_keys' === $id ){

			$checkboxs = [];

			$metas_data = kpviews()->meta_keys_data();
			$is_all_selected = ! array_diff( array_keys( $metas_data ), $val );

			foreach( $metas_data as $opt_key => $opt_label ){

				$opt_label = preg_replace( '/`([^`]+)`/', '<code>\1</code>', $opt_label );

				$checkboxs[] = sprintf(
					'<label><input type="checkbox" name="%s" value="%s" %s>%s</label>',
					"{$name}[]", $opt_key, checked( in_array( $opt_key, $val, true ), true, 0 ), $opt_label
				);
			}

			?>
			<fieldset class="meta_keys_checkboxes_js" <?= $is_all_selected ? 'style="display:none;"' : '' ?>>
				<?= $desc ?><br>
				<?= implode( '<br>', $checkboxs ) ?>
			</fieldset>

			<fieldset>
				<label><input class="meta_keys_all_checkbox_js" type="checkbox" <?= checked( $is_all_selected, true, 0 ) .'>'. __( 'All', 'kap' ) ?></label>
			</fieldset>

			<h4><?= __( 'Delete meta-data from database if You don\'t need it.', 'kap' ) ?></h4>
			<?php

			// delete metadata
			if( 'delete metadata' ){

				$meta_rows = $wpdb->get_results( "SELECT meta_key, count(*) as count FROM $wpdb->postviews_meta GROUP BY meta_key", OBJECT_K );

				if( $meta_rows ){

					$options = [];

					foreach( $metas_data as $opt_key => $opt_label ){

						if( ! isset( $meta_rows[ $opt_key ] ) || ! $meta_rows[ $opt_key ]->count ){
							continue;
						}

						$meta_count = $meta_rows[ $opt_key ]->count;

						$options[] = sprintf( '<option value="%s">%s</option>',
							$opt_key, sprintf( '%s - %s rows', "<b>$opt_key</b>", $meta_count )
						);
					}
					?>
					<select class="delete_db_meta_select_js">
						<option value=""> — </option>
						<?= implode( '', $options ) ?>
					</select>
					<span class="button delete_db_meta_btn_js"><?= __( 'Delete Metadata', 'kap' ) ?></span>
					<?php
				}
				else {
					?>
					<span><?= __( 'There is no data for delete for now.', 'kap' ) ?></span>
					<?php
				}

			}
		}

		elseif( in_array( $id, [ 'hold_sec', 'hold_sec_between_counts' ], true ) ){
			echo '<input type="number" min="0" name="'. $name .'" value="'. esc_attr( $val ) .'" style="width:100px;">'. $desc;
		}

		elseif( 'blocktypes' === $id ){

			$def_blocktypes = kpviews()->default_options()['blocktypes'];

			$types = [
				'common'     => kpviews()->get_available_types('common'),
				'post_types' => kpviews()->get_available_types('post_types'),
				'taxonomies' => kpviews()->get_available_types('taxonomies'),
			];

			$checkboxes = [ 'common' =>'', 'post_types' =>'', 'taxonomies' =>'', ];
			foreach( $types as $key => $btypes ){

				foreach( $btypes as $btype_name ){

					$checked = in_array( $btype_name, (array) $val, true ) ? 'checked' : '';

					$name_sign = in_array( $btype_name, $def_blocktypes, true ) ? __('default','kap') : '';

					$label_class = '';

					if( $btype_name === 'post' ){
						$label_class = ' class="global disable_count_group_js" ';
						$name_sign = __('all posts','kap');
					}

					if( $btype_name === 'term' ){
						$label_class = ' class="global disable_count_group_js" ';
						$name_sign = __('all terms','kap');
					}

					$checkboxes[ $key ] .= '
						<label'. $label_class .'>
							<input type="checkbox" name="'. $name .'[]" value="'. $btype_name .'" '. $checked .' />
							<small>'. __('not','kap') .'</small> <code>'. $btype_name .'</code><small>'. ( $name_sign ? "- $name_sign" : '' ) .'</small>
						</label>
					';
				}

			}

			// прячем
			if( in_array( 'post', (array) $val, 1 ) ){
				$checkboxes['post_types'] = str_replace( '<label>','<label style="display:none;">', $checkboxes['post_types'] );
			}
			if( in_array( 'term', (array) $val, 1 ) ){
				$checkboxes['taxonomies'] = str_replace( '<label>','<label style="display:none;">', $checkboxes['taxonomies'] );
			}

			echo $desc . '
				<div class="btypes-wrap">
					<style>
						.btypes-wrap{ display:-webkit-box; display:-ms-flexbox; display:flex; margin-top:1em; }
						.btypes-wrap label{ display:block; padding:.2em 2em .2em 0; }
					</style>
					<div>'. implode('</div><div>', $checkboxes ) .'</div>
				</div>';
		}

		elseif( 'licence_key' === $id ){
			$val = get_option( basename( KPV_PATH ) .'_license_key' );
			echo '<input type="text" name="'. $name .'" value="'. esc_attr( $val ) .'" style="width:300px;">'. $desc;
		}

		elseif( 'show_prev_m_views' === $id ){
			echo '
			<input type="hidden" name="'. $name .'" value="">
			<label><input type="checkbox" name="'. $name .'" value="1" '. checked($val, 1, 0) .'> '. $args['desc'] .'</label>';
		}

		elseif( $id === 'clear_db_tables' ){
			echo Clear_Database::clear_option_html();
		}

	}

	public function _option_sanitize_cb( $options ){

		foreach( $options as $name => & $val ){

			if( 'allowed_meta_keys' === $name ){

				if( 'all' === $val || ! array_diff( array_keys( kpviews()->meta_keys_data() ), $val ) ){
					$val = 'all';
				}
				else{
					$val = array_map( 'sanitize_key', array_filter( array_map( 'trim', $val ) ) );
				}

			}
			elseif( 'blocktypes' === $name ){

				if( is_string( $val ) ){
					$val = preg_split( '/[,\s]+/', $val );
				}

				$val = array_map( 'sanitize_key', array_filter( array_map( 'trim', $val ) ) );
			}
			elseif( 'licence_key' === $name ){
				$optname = basename( KPV_PATH ) .'_license_key';
				update_option( $optname, $val );
				unset( $options[$name] );
			}
			elseif( is_string( $val ) ){
				$val = sanitize_text_field( $val );
			}
		}

		return $options;
	}

}

