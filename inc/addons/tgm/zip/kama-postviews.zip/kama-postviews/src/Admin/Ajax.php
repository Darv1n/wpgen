<?php

namespace Kama_Postviews\Admin;

class Ajax {

	function delete_meta_key_data(){
		global $wpdb;

		if( ! current_user_can( 'manage_options' ) ){
			die( 'no access' );
		}

		$meta_key = sanitize_key( $_POST['meta_key'] );

		if( $wpdb->delete( $wpdb->postviews_meta, [ 'meta_key' => $meta_key ] ) ){
			die( 'ok' );
		}

		die( 'not deleted' );
	}

}