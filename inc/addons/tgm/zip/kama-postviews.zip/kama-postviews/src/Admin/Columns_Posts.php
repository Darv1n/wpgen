<?php

namespace Kama_Postviews\Admin;

class Columns_Posts extends Columns_Common {

	static function init( $post_types ){

		foreach( $post_types as $ptype ){

			add_filter( "manage_{$ptype}_posts_columns", [ __CLASS__, 'add_post_column' ], 10 );

			add_filter( "manage_{$ptype}_posts_custom_column", [ __CLASS__, 'fill_post_column' ], 5, 2 );

			add_filter( "manage_edit-{$ptype}_sortable_columns", [ __CLASS__, 'add_sortable_column' ] );
		}

		// изменяем запрос при сортировке колонки
		add_filter( 'pre_get_posts', [ __CLASS__, '_post_sort_request' ] );
	}

	static function add_post_column( $columns ){
		return self::_add_column( 'post', $columns );
	}

	static function fill_post_column( $colname, $post_id ){

		if( in_array( $colname, [ 'views', 'views_prev_month' ] ) ){
			echo self::_fill_column( 'post', $post_id, $colname );
		}
	}

	static function _post_sort_request( $wp_query ){

		if(
			! is_admin()
			||
			! in_array( $wp_query->get( 'orderby' ), [ 'views', 'views_prev_month', KPV_META_KEY, KPV_PREV_MONTH_META_KEY ], true )
		){
			return;
		}

		$orderby = $wp_query->get( 'orderby' );
		$map = [
			'views' => KPV_META_KEY,
			'views_prev_month' => KPV_PREV_MONTH_META_KEY,
		];
		if( isset( $map[ $orderby ] ) ){
			$orderby = $map[ $orderby ];
		}

		$wp_query->set( 'meta_key', $orderby );
		$wp_query->set( 'orderby', 'meta_value_num' );
	}

}