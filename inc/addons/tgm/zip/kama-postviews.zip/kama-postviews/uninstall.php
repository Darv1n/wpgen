<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'kama_postviews' );
delete_option( 'kama_postviews_ver' );
delete_option( 'kama_autoupdate_class' );

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}postviews" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}postviews_meta" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}postviews_temp_log" );

// delete meta
// don't touch 'views' meta it can be be useful
$wpdb->query( "DELETE FROM $wpdb->postmeta WHERE meta_key IN ( 'views_prev_month', '_views_prev_month_up' )" );
if( isset( $wpdb->termmeta ) ){
	$wpdb->query( "DELETE FROM $wpdb->termmeta WHERE meta_key IN ( 'views_prev_month', '_views_prev_month_up' )" );
}
