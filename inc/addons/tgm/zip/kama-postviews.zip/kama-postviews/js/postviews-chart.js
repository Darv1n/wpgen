'use strict'

window.kama_postviews_chart = {

	inited : false,
	options : null,
	colors : null,
	lables_sort_order : 'all unique mobile google yandex direct inner',
	colors_theme: 'tomorrow_hard', // tomorrow_soft | tomorrow_hard // replaces with option

	init : function( data_callback ){

		if( this.inited ){
			this.draw( data_callback() )
			return
		}

		// once

		this.inited = true

		this.set_colors()

		this.set_options()

		const wait_chart = function(){

			if( typeof window.Chart === 'undefined' ){
				setTimeout( wait_chart, 100 )
			}
			else {
				window.kama_postviews_chart.chartjs_loaded()
				window.kama_postviews_chart.draw( data_callback() )
			}
		}

		setTimeout( wait_chart, 100 )
	},

	chartjs_loaded : function(){

		// setup tooltip_positioner function
		window.Chart.registry.getPlugin('tooltip').positioners['myTooltipPositioner'] = function( elements, event ){

			if( ! elements.length )
				return false

			const chart = this._chart;
			const offset = ( chart.width / 2 > event.x ) ? 150 : -150;

			return {
				x: event.x + offset,
				y: chart.height / 2
			}
		}

	},

	draw : function( data ){

		const chart = document.getElementById( 'kpv-chart' )

		// delete a chart if it has already been created and create a new one
		if( chart.chartCanvas ){
			chart.chartCanvas.destroy()
		}

		chart.chartCanvas = new Chart( chart, {
			type   : 'line',
			data   : data,
			options: this.options
		} )

		// TODO hide data by default see https://stackoverflow.com/questions/49053147/hide-dataset-by-default-using-chart-js-and-a-custom-script/49053466
		// chart.chartCanvas.getDatasetMeta( 1 ).hidden = true
		// chart.chartCanvas.update()
	},

	set_colors : function(){

		switch( this.colors_theme ){

			case 'tomorrow_hard' :

				this.colors = {
					all   : '#3e999f', // Aqua
					direct: '#8959a8', // purple
					inner : '#eab700', // yellow
					others: '#676767', // grey
					// changeable
					yandex    : '#c82829', // red
					zen_yandex: '#c82829', // red
					google    : '#f5871f', // Orange
					facebook  : '#4267b2', // facebook
					vk        : '#4c75a3', // vk
					unique    : '#718c00', // green
					mobile    : '#4271ae', // Blue
				}
				break

			case 'tomorrow_soft' :

				this.colors = {
					all   : '#6cc',    // Aqua
					direct: '#c9c',    // Purple
					inner : '#fc6',    // Yellow
					others: '#868686', // grey
					// changeable
					yandex    : '#f2777a', // red
					zen_yandex: '#f2777a', // red
					google    : '#f99157', // Orange
					facebook  : '#4267b2', // facebook
					vk        : '#4c75a3', // vk
					unique    : '#9c9',    // green
					mobile    : '#6699cc', // Blue
				}
				break
		}

	},

	set_options : function(){

		const lables_sort_order = this.lables_sort_order.split( ' ' )

		this.options = {

			responsive: true,
			responsiveAnimationDuration: 0, // animation duration after a resize
			maintainAspectRatio: false,     // высота ширина на базе контейнера
			hover: {
				intersect: false,
				mode: 'index',
			},
			interaction: {
				intersect: false,
				mode: 'index',
			},
			plugins: {

				legend: {
					position: 'top',
					labels: {
						usePointStyle: true,
						pointStyle: 'rect',
						padding: 15,
						sort : function( aitem, bitem, data ){

							let aindex = lables_sort_order.findIndex( val => aitem.text === val.toLowerCase() )
							let bindex = lables_sort_order.findIndex( val => bitem.text === val.toLowerCase() )

							let afound = ( -1 !== aindex )
							let bfound = ( -1 !== bindex )

							if( bfound && afound )
								return ( aindex > bindex ? 1 : -1 )
							if( ! bfound )
								return -1

							return 0
						}
					},
					// TODO save current hidden elements to local storage
					// see https://www.chartjs.org/docs/latest/configuration/legend.html
					//onClick: function( event, legendItem, legend ) {
					//	console.log( "legend click @ x: " + event.clientX + ", y:" + event.clientY );
					//}
				},

				tooltip: {
					position : 'myTooltipPositioner',

					borderColor : 'rgba(0, 0, 0, 0.1)',
					borderWidth : 1,
					backgroundColor : 'rgba(255,255,255,0.8)',
					titleColor  : '#333',
					bodyColor   : '#333',
					footerColor : '#333',
					padding     : 10,

					// DESC sort
					itemSort: function( a, b ){
						let [ aa, bb ] = [ a.parsed.y, b.parsed.y ]
						return aa === bb ? 0 : ( aa <bb ? 1 : -1 )
					},

					callbacks: {
						title: tooltipItems => {
							// 5 янв 2020 (7541) → 5 янв 2020
							return tooltipItems[0].label.replace( /::.+/, '' ).trim()
						},
						footer: tooltipItems => {

							let per_month = tooltipItems[0].label.match( /::([0-9]+)$/ )[1].trim()

							return 'Per Month: ' + per_month;
						},
						labelColor: context => {
							return {
								borderColor: 'rgba(0,0,0,0)',
								backgroundColor: context.chart.config.data.datasets[ context.datasetIndex ].borderColor
							}
						},
						// TODO add % of total
						//afterLabel: TooltipItem => {
						//	return 'aaa';
						//	console.log( TooltipItem )
						//}
					}
				},
			},
			scales: {
				x: {
					display: false, // off X axis labels
				}
			},
			elements: {
				line: {
					tension     : 0, // sharp corners
					borderWidth : 2, // line width
				},
				point: {
					radius: 0,
					hoverRadius: 3,
				},
			},
		}
	},

}