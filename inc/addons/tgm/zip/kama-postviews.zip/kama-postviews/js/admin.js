
document.addEventListener( 'DOMContentLoaded', function(){

	// show hide disable count group
	document.querySelectorAll( '.disable_count_group_js input' ).forEach( function( input ){

		input.onclick = function( ev ){

			if( input.matches( ':checked' ) ){
				jQuery( input.parentElement ).nextAll().hide()
			}
			else{
				jQuery( input.parentElement ).nextAll().show()
			}

		}
	} )

	// delete meta key data
	document.querySelector( '.delete_db_meta_btn_js' ).onclick = function( btn ){

		let select = document.querySelector('.delete_db_meta_select_js')

		let meta_key = select.value

		if( ! meta_key || ! confirm( `DELETE >>>> ${ meta_key } <<<< meta key data?` ) )
			return

		jQuery.post( ajaxurl, { action:'kpv_delete_meta_key_data', meta_key }, function( resp ){

			if( 'ok' === resp ){
				select.querySelector( `option[value="${meta_key}"]` ).delete()
			}

		} );
	}

	// meta keys deletion All checkboxe
	let all_checkbox = document.querySelector( '.meta_keys_all_checkbox_js' )
	let checkboxes = document.querySelector( '.meta_keys_checkboxes_js' )
	all_checkbox.onchange = function( ev ){

		let the = ev.currentTarget

		if( the.matches(':checked') ){
			checkboxes.querySelectorAll('[type=checkbox]').forEach( function( checkbox ){
				checkbox.checked = true
			} )
			checkboxes.style.display = 'none'
		}
		else{
			checkboxes.style.display = 'block'
		}
	}

} )