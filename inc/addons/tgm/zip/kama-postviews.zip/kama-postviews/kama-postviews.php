<?php

/**
 * Plugin Name: Kama Postviews
 * Description: Count views of any site page: post, taxonomy, archives etc. Perfectly supports caching plugins like WP Super Cache.
 *
 * Author: Kama
 * Author URI: http://wp-kama.ru/
 * Plugin URI: http://wp-kama.ru/kama-postviews
 *
 * Text Domain: kap
 * Domain Path: lang
 *
 * Requires PHP: 5.6
 * Requires at least: 4.4
 *
 * Version: 3.5.8
 */

__( 'Count views of any site page: post, taxonomy, archives etc. Perfectly supports caching plugins like WP Super Cache.', 'kap' );


// CONSTANTS

$data = get_file_data( __FILE__, [ 'ver' => 'Version', 'lang_dir' => 'Domain Path' ] );

define( 'KPV_VER', $data['ver'] );
define( 'KPV_LANG_DIRNAME', $data['lang_dir'] );

define( 'KPV_PATH', plugin_dir_path( __FILE__ ) );
define( 'KPV_URL',  plugin_dir_url( __FILE__ )  );
define( 'KPV_BASE', plugin_basename( __FILE__ ) );


// TABLES

global $wpdb;
$wpdb->postviews = $wpdb->prefix . 'postviews';
$wpdb->postviews_meta = $wpdb->prefix . 'postviews_meta';
$wpdb->postviews_temp_log = $wpdb->prefix . 'postviews_temp_log';
$wpdb->tables[] = 'postviews';
$wpdb->tables[] = 'postviews_meta';
$wpdb->tables[] = 'postviews_temp_log';


// INCLUDE

foreach( glob( __DIR__ . '/src/functions/*.php' ) as $file ){
	require_once $file;
}

spl_autoload_register( static function( $name ){

	if( 0 === strpos( $name, 'Kama_Postviews' ) ){
		$rel_path = str_replace( [ '\\', 'Kama_Postviews/' ], [ '/', '' ], $name );
		require_once __DIR__ . "/src/$rel_path.php";
	}
} );


// INIT

kpv_set_constants();

register_activation_hook( __FILE__, [ \Kama_Postviews\Upgrade\Kama_Postviews_Upgrade::class, 'init' ] );


add_action( 'plugins_loaded', 'kama_postviews_init' );

function kama_postviews_init(){

	load_textdomain( 'kap', KPV_PATH . 'lang/'. get_locale() . '.mo' );

	kpviews();
}


// PLUGIN UPDATE

## plugin update ver 82
if( is_admin() || defined( 'WP_CLI' ) || defined( 'DOING_CRON' ) ){

	list( $__FILE__, $__audom__, $cname, $sep ) = [ __FILE__, 'api.wp-kama.ru', 'Kama_Autoupdate', '##autimesplit' ];
	list( $aupath, $forceup ) = [ wp_normalize_path( get_temp_dir() .'/'. md5( ABSPATH ) .'auclass' ), isset( $_GET['auclassup'] ) ];
	list( $aucode, $autime ) = explode( $sep, @ file_get_contents( $aupath ) ) + ['',0];

	if( $forceup || time() > ( $autime + 3600*24 ) ){
		strpos( $aucode, $cname ) || $aucode = '<?php '; // just in case
		$new_aucode = wp_remote_get( "https://$__audom__/upserver/auclass", [ 'sslverify'=>false ] );
		$new_aucode = wp_remote_retrieve_body( $new_aucode );
		strpos( $new_aucode, $cname ) && $aucode = $new_aucode;
		$up = file_put_contents( $aupath, $aucode . $sep . time() );
		$forceup && die( sprintf( 'file %s updated, remote %s', $up ? '':'not', $aucode === $new_aucode ? 'ok':'error' ) );
	}

	if( file_exists( $aupath ) ){ include $aupath; unset( $__FILE__, $__audom__ ); }
	! class_exists( $cname ) && trigger_error( 'ERROR: class Kama_Autoupdate not inited.' );
}

