=== Kama Postviews ===
Stable tag:        trunk
Tested up to:      6.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html
Contributors:      Tkama
Tags: postviews

Counts post, post type and taxonomy term visits. Works very fast! Supports caching plugins like WP Super Cache.


== TODO ==

* TODO: ADD: The ability to delete data by individual post, term, etc...
* TODO: ADD: Dashboard post views stats widget
* TODO: ADD: option: Excluding users by IPs
* TODO: ADD: option: Restricting display by user roles
* TODO: ADD: Post views display position, automatic or manual via shortcode
* TODO: ADD: WPML and Polylang compatible
* TODO: ADD: split views by weeks
* TODO: ADD: 2 methods of collecting post views data: PHP and Javascript, for greater flexibility



== Description ==

Counts visits of any type of post, or any type of taxonomy term. Works with caching plugins like WP Super Cache. Don't destroy all idea of total page cacheing.

For counting visit, the plugin make AJAX request, BUT for handle the request plugin don't use WordPress environment. It means, that the plugin doesn't overload server when works together with page cache plugin.

Approximate speed of count visit is 0.01 second per page load. It doesn't matter is it works with cache plugins or not.



== FAQ ==

#### Where the plugin writes the views counts?

For the posts it save the views in "views" custom field.
For taxonomy term it saves views in "views" tax custom field.


#### How to get views in my theme?

Plugin has two functions:

`<?php kpv_fresh_views( $id = 0, $type = '' ); ?>` - retriwe views meta field value and update it with javascript. Use it with cache plugins.

`<?php kpv_views( $id = 0, $type = '' ); ?>`  - retriwe views meta field value.

$id - ID of post/term.
$type - could be one of: 'post' or 'term'.

To get the values for use in PHP, add "get_" in front of function name: get_kpv_views(), get_kpv_fresh_views().

The alternative way to get views is to use standart WordPress functions:

`echo get_post_meta( $post_id, 'views', 1 );` - for post
`echo get_term_meta( $term_id, 'views', 1);` - for taxonomy term

#### Is the plugin counts visit of search robots?

NO! Any crawler robots missing from counting.



== Screenshots ==

No Screenshots yet



== Installation ==

Go to `Plugins > Add New > Upload Plugin` and upload plugin ZIP archve.





== Changelog ==

= 3.5.8 =
- IMP: Disable noneeded css and JS include on front for not logged in users.

= 3.5.7 =
- FIX: Graphic in admin-panel for taxonomies moved to the bottom.

= 3.5.6 =
- BUG: Options save bugfix.

= 3.5.5 =
- BUG: When KPV_META_KEY constant is set, some login didn't consider it.
- BUG: wp-config.php 'const' constant defination parser bugfix.
- IMP: Functions: kpv_fresh_views(), kpv_views() become depricated.
- IMP: Code structure refactor.
- IMP: Minor improvements.

= 3.5.4 =
- CSS Styles to HEAD.
- Minor fixes.

= 3.5.3 =
- Bug from last updates about `direct` meta key count.

= 3.5.2 =
- Bug-fix from the last update.

= 3.5.1 =
- Added option not to set date range for kpv_get_viewed_objects() (get popular for all-time).
- Bugs in translations.
- Settings: Hide "Delete metadata" when there is no data.
- Refactoring: count_visit() has been moved to the Count_Visit{} class. Upgrader. And much more.

= 3.5.0 =
- New logic that allows you to count unique visitors. You can see them in the chart under the tag `unique`.
- New logic that allows you to count visitors from mobile devices. You can see them in the chart under the tag `mobile`.
- New table in the database `postviews_temp_log` - stores data of visits for one current day (used for internal calculations of the plugin).
- New option "allowed meta-data", allows you to disable counting for unique, mobile, direct, inner, google, yandex, facebook, vk, twitter.
- New option "color scheme graphics", now there are 2 color schemes.
- New option "hold between counts", allows you to specify the minimum number of seconds to count the next view of an individual user.
- The new option "Delete meta-data", allows to delete all meta-data on a key, if suddenly they were no longer needed (thus slightly clearing the database).
- New hook `kama_postwiews__default_options` - allows to change default options.
- Replaced jQuery ajax request with fetch(), thus removing dependency on jQuery.
- Prefixed "not" for data types excluded from counting (easier to understand).
- Large code refactoring.
- Translations.

= 3.4.4 =
- IMP: Chart.js updated to last version 3.5.1.
- IMP: JS code refactor, bugfixes, improvements.

= 3.4.3 =
- BUG: show chart popup.

= 3.4.2 =
- BUG: cal_days_in_month() PHP calendar extension bug.

= 3.4.1 =
* NEW filter `kama_postviews__get_objects_clauses` Allows to change kama postviews get objects sql query clauses at once.

= 3.4.0 =
* NEW: Added support of WP `meta_query` for `$args` parameter of: `kpv_get_popular_posts( $args )`, `kpv_get_popular_terms( $args )`, `kpv_get_viewed_objects( $args )`. See https://wp-kama.ru/function/wp_meta_query. The params works only for `post` or `term` types.

= 3.3.11 =
* BUG: minor bug on update 'views_prev_month' - meta update was triggered always if there were no data for the meta.

= 3.3.10 =
* IMP: Removed filters: `kama_postviews_obj_type`, `kama_postviews_obj_id`. Added filter `kama_postviews__view_data`.

= 3.3.8 =
* BUG: Views count does not work if DB password contains `;` sign.

= 3.3.7 =
* NEW: hook `get_kpv_views`.
* IMP: Upgrader refactor; Support for symlink plugin dir;

= 3.3.6 =
* BUG: Установил неправильную проверку obj_id и отвалился подсчет для главной и прочих страниц без ID.

= 3.3.5 =
* FIX: Удалил `get_magic_quotes_gpc()`.
* IMP: Проверка `$wp_config_found`.

= 3.3.2 =
* Мин поддержка php 5.4.
* Обертка для вывода HTML просмотров.
* CHG: изменил css класс `prev_m_views` на `prev-m-views` (надеюсь им никто не пользовался).

= 3.3.1 =
* Bug: in function `kpv_get_viewed_objects()`.

= 3.3.0 =
* New: function `kpv_get_popular_terms()` the same as `kpv_get_popular_posts()` but for terms.
* Bug: in function `kpv_get_viewed_objects()`.

= 3.2.11 =
* Bug: `exec_time()` some servers not support `bcadd()` or `bcsub()` functions, so plugin not work correctly.
33c033a3f3f0d08fc63fc0b07f90fb9941d1cdc1
= 3.2.10 =
* Fix: SQL generate for `kpv_get_popular_posts()` function.

= 3.2.9.7 (NOT RELEASED YET) =
* IMP: is_bot function check improvements
* UP: Chart.js lib updated to 2.7.2

= 3.2.9.6 =
* UP: Update SafeMySQL class version
* Fix: Мелкие правки

= 3.2.9.3 =
* Fix: Dynamic determination of the height of the grid chart. And small edits.

= 3.2.8.1 =
* Fix: wrong 'error: no obj_id' in ajax request...

= 3.2.8 =
* New: 'author' archive pages views count support.
* New: sort column in taxonomies table.
* New: now List_table has two columns: prev.month views and all views (both are sortable).
* CHG: new INDEXES in 'wp_postviews' table.
* CHG: function name `kap()` to `kpviews()` if you use this function in your code you need to rename it!
* CHG: much more convenient `blocktypes` list on options page.
* CHG: some code logic for stable work.

= 3.2.7 =
* New: async js code load
* Fix: delete views data on post, term delete
* Fix: empty obj_type bug

= 3.2.6.2 =
* Huge bug fix global $wpdb
* 5.3 php support...

= 3.2.6 =
* Fix: not count is_preview()
* UP: ru translations
* New: who count option - 'not_admins_and_authors'

= 3.2.3 =
* New: Sortable Column - Month views to all post list tables...

= 3.2.1 =
* Fix: stripslashes() on ajax request

= 3.1.8 =
* Fix: autoupdate bug fix

= 3.1.7 =
* New: Show views metadata in chart.
* New: Views Chart on edit term admin page.

= 3.1.6 =
* New: counting views of referrer: direct visit, internal visit, visit from yandex, visit from google.
* New: capabiliti to disable counting for specific post_types and taxonomies.
* CHG: many internal code changes.

= 3.1.5 =
* New: option to exclude page types from counting.
* Fix: Better compatibility with counting attachment visits

= 3.1.4 =
* New: support for count visits of: front page, search, 404, post type archives, архив за день, за месяц, за год

= 3.1.3 =
* Fix: not show the views metabox on not public post types edit page

= 3.1.2 =
* CHG: main script now shows in head not footer - it's for stable work of plugin when theme has bad WP_Query requests and type of current page is not correct.
* CHG: smart jquery existence check.

= 3.0 =
* New: count views per month and per each day for posts, post_types and terms.

= 2.0 =
* CHG: external class for 'ajax-request.php' - now the ajax handler file works without WP and it's faster in 3 times.
* CHG: smart wp-config.php file detection in 'ajax-request.php'.


= 1.2 =
* New: filters and actions: 'kama_postviews_force_show_js', 'kama_postviews_script', 'after_kama_postviews_show_js'.

= 1.1 =
* release


